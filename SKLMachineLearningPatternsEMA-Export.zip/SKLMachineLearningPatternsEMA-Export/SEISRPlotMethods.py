#!/opt/local/bin python

    #   SEISRPlotMethods.py   Contains plot routines for the EMA code
    #
    #
    #   This code was written on a Mac using Macports python, but Anaconda python should work as well.
    
    #   ---------------------------------------------------------------------------------------
    
    # Copyright 2022 by John B Rundle, University of California, Davis, CA USA
    # 
    # Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
    # documentation files (the     "Software"), to deal in the Software without restriction, including without 
    # limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
    # and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
    # 
    # The above copyright notice and this permission notice shall be included in all copies or suSKLantial portions of the Software.
    # 
    # THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
    # WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
    # COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
    # ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

    #   ---------------------------------------------------------------------------------------
    
import sys
import os
import numpy as np
from array import array

import SEISRCalcMethods
import SEISRFileMethods
import SEISRUtilities

import datetime
import dateutil.parser

import time
from time import sleep  #   Added a pause of 30 seconds between downloads

import math

from tabulate import tabulate

#  Now we import the sklearn methods
import pandas as pd
import numpy as np
import scipy
from numpy import arange
from scipy.interpolate import UnivariateSpline
from scipy.optimize import fsolve

from numpy import asarray
from pandas import read_csv
from pandas import DataFrame
from pandas import concat

import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator
import matplotlib.patches as mpatches
from matplotlib import gridspec

from matplotlib.offsetbox import AnchoredText
from matplotlib.image import imread
import matplotlib.ticker as mticker

from scipy.integrate import simps
from numpy import trapz

import itertools

import cartopy
import cartopy.crs as ccrs
import cartopy.feature as cfeature

import cartopy.io.img_tiles as cimgt
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
from cartopy.feature import NaturalEarthFeature, LAND, COASTLINE

#from sklearn.datasets import load_iris     #   Don't need this dataset

from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn import svm
from sklearn.ensemble import RandomForestClassifier
from sklearn import preprocessing
from sklearn.metrics import mean_absolute_error
from sklearn.ensemble import RandomForestRegressor

import random
    

from matplotlib import pyplot

    ######################################################################
    ######################################################################
    
def plot_seisr_timeseries(time_list_reduced, log_number_reduced, plot_start_year, mag_large_plot,\
        NELng_local, SWLng_local, NELat_local, SWLat_local, Location, NSteps, delta_time_interval, min_mag, lambda_mult, min_rate,\
        max_rate, forecast_interval, number_thresholds, \
        true_positive, false_positive, true_negative, false_negative, threshold_value):
        
#     
#
#   ------------------------------------------------------------
#
    year_large_eq, mag_large_eq, index_large_eq = SEISRCalcMethods.get_large_earthquakes(mag_large_plot,min_mag)
    
#     optimal_threshold = \
#             SEISRCalcMethods.compute_optimal_threshold(true_positive, false_positive, true_negative, false_negative,\
#             threshold_value)
#
#   ------------------------------------------------------------
#
        
    fig, ax = plt.subplots()
    
    ax.plot(time_list_reduced, log_number_reduced, linestyle='-', lw=1.0, color='b', zorder=3)

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    year_large_eq, mag_large_eq, index_large_eq = \
            SEISRCalcMethods.adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, time_list_reduced, plot_start_year)
            
   #   -------------------------------------------------------------

    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999  and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymax,log_number_reduced[index_large_eq[i]]]
            
            ax.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2)
            
    ax.plot(x_eq,y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2, label = '6.9 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.89999 and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymax,log_number_reduced[index_large_eq[i]]]
            
            ax.plot(x_eq, y_eq, linestyle='--', color='r', lw=0.7, zorder=2)
            
    ax.plot(x_eq,y_eq, linestyle='--', color='r', lw=0.7, zorder=2, label='M $\geq$ 6.9')

    #   -------------------------------------------------------------
    
    max_plot_line = [ymax for i in range(len(time_list_reduced))]
    ax.fill_between(time_list_reduced , max_plot_line, log_number_reduced, color='c', alpha=0.1, zorder=0)
    
    plt.gca().invert_yaxis()
            
    ax.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    
    ax.legend(loc = 'upper left', fontsize=7)
    
    #     
    #   ------------------------------------------------------------
    #
            
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'
        
    Rmax_plot = str(round(max_rate,0))
    if max_rate > 10000:
        Rmax_plot = 'Inf.'
        
    textstr =   'EMA Samples (N): ' + str(NSteps) +\
                '\nTime Step: ' + str_time_interval +\
                '\n$R_{min}$: ' + str(round(min_rate,0)) +\
                '\n$R_{max}$: ' + Rmax_plot +\
                '\n$M_{min}$: ' + str(round(min_mag,2))

# 
#     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

#     # place a text box in upper left in axes coords
    ax.text(0.015, 0.02, textstr, transform=ax.transAxes, fontsize=7,
        verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)


#   ------------------------------------------------------------
#

    ax.minorticks_on()
    
    ax.tick_params(axis='both', labelsize=11)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    SupTitle_text = 'Seismicity State $\Theta(t)$ vs. Time: ' 

    plt.suptitle(SupTitle_text, fontsize=14, y = 0.96)
    
    Title_text = 'Within ' + str(round(delta_deg_lat,2)) + '$^o$ Latitude and ' + str(round(delta_deg_lng,2)) + '$^o$ Longitude of ' + Location\
        + ' (Note Inverted Y-Axis)'
            
    plt.title(Title_text, fontsize=9)
    
    plt.ylabel('$\Theta(t) = Log_{10}$ (1 + Monthly Number)', fontsize = 11)
    plt.xlabel('Time (Year)', fontsize = 11)
    
    data_string_title = 'EMA' + '_FI' + str(forecast_interval) + '_TTI' + str(test_time_interval) + \
            '_NSTP' + str(NSteps) + '_MM' + str(min_mag) + '_CF' + str(lambda_mult) 

    figure_name = './Data/SEISR_' + data_string_title + '_' + str(plot_start_year) + '.png'
    plt.savefig(figure_name,dpi=600)
    
#     plt.show()
#     matplotlib.pyplot.close('all')
    plt.close('all')

    return 
    
    ######################################################################
    
def plot_timeseries_precision_information(time_list_reduced, log_number_reduced, \
        plot_start_year, mag_large_plot, mag_large, min_mag,\
        NELng_local, SWLng_local, NELat_local, SWLat_local, Location, NSteps, delta_time_interval, lambda_mult, min_rate,\
        forecast_interval, number_thresholds, threshold_value, \
        true_positive, false_positive, true_negative, false_negative, \
        true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate,\
        year_large_eq, mag_large_eq, index_large_eq):
        
    #
    #   ------------------------------------------------------------
    #
    #  Set up the plots

    fig = plt.figure(figsize=(10, 6))        #   Define dimensions of plot
#     fig, (ax0, ax1, ax2) = plt.figure(figsize=(10, 6))
    
#     fig, (ax0, ax1, ax2) = plt.subplots(1,3)

    gs = gridspec.GridSpec(1,3,width_ratios=[10, 5, 5], wspace = 0.2) # 3 plots 1 row, 3 columns
    
    ax0 = plt.subplot(gs[0])
    
    #
    #   =======================================================================
    #
    #   First get the large earthquakes
    #
    #
    #   -------------------------------------------------------------
#     fig, ax = plt.subplots()
    
    ax0.plot(time_list_reduced,log_number_reduced, linestyle='-', lw=1.0, color='b', zorder=3)

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    year_large_eq, mag_large_eq, index_large_eq = \
            SEISRCalcMethods.adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, time_list_reduced, plot_start_year)
    
   #   -------------------------------------------------------------

    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999  and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymax,log_number_reduced[index_large_eq[i]]]
            
            ax0.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2)
            
    ax0.plot(x_eq,y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2, label = '6.9 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.89999 and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymax,log_number_reduced[index_large_eq[i]]]
            
            ax0.plot(x_eq, y_eq, linestyle='--', color='r', lw=0.7, zorder=2)
            
    ax0.plot(x_eq,y_eq, linestyle='--', color='r', lw=0.7, zorder=2, label='M $\geq$ 6.9')

    #   -------------------------------------------------------------
    
    min_plot_line = [ymax for i in range(len(time_list_reduced))]
    ax0.fill_between(time_list_reduced , min_plot_line, log_number_reduced, color='c', alpha=0.1, zorder=0)
    
    plt.gca().invert_yaxis()
            
    ax0.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    
    ax0.legend(loc = 'upper left', fontsize=9)
    
    ax0.tick_params(axis='both', labelsize=9)
    
    #  
    #   ------------------------------------------------------------
    #
    
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

    textstr =   '$M_{Large}\geq$: '+ str(mag_large) +\
                '\n$T_W$: ' + str(round(forecast_interval,1)) + ' Years' +\
                '\nEMA Samples (N): ' + str(NSteps) +\
                '\nTime Step: ' + str_time_interval +\
                '\n$R_{min}$: ' + str(round(min_rate,0))+\
                '\n$M_{min}$: ' + str(round(min_mag,2))
 
    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    #     # place a text box in upper left in axes coords
    ax0.text(0.035, 0.02, textstr, transform=ax0.transAxes, fontsize=6,
        verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.5)
        
    #     
    #   -------------------------------------------------------------
    #

    ax0.minorticks_on()
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    SupTitle_text = 'Information Content of Seismicity\nWithin ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location

    plt.suptitle(SupTitle_text, fontsize=12, y = 0.985)
    
    Title_text = 'State Variable $\Theta(t)$ vs. Time' 
            
    plt.title(Title_text, fontsize=9)

    plt.ylabel('$\Theta(t) = Log_{10}$ (1 + Monthly Number)', fontsize = 9)
    plt.xlabel('Time (Year)', fontsize = 9)
    
    #
    #   =======================================================================
    #
    #   Second plot: Precision    
    
    ax1 = plt.subplot(gs[1])
#     frame1 = plt.gca()
    # 
    #   -------------------------------------------------------------
    #
    
    number_random_timeseries = 50
                
    precision, precision_info, threshold_reduced = SEISRCalcMethods.calc_precision_threshold\
            (true_positive, false_positive, false_negative, true_negative, threshold_value)
            
    values_window = log_number_reduced
    times_window  = time_list_reduced

    random_precision_list, mean_random_precision, random_upper, random_lower = \
            SEISRCalcMethods.calc_random_precision_threshold\
            (precision, values_window, times_window, forecast_interval, mag_large, min_mag,\
            number_thresholds, number_random_timeseries)
            
            
    precision_percent = [precision[i]*100.0 for i in range(len(precision))]
    ax1.plot(precision_percent, threshold_reduced, linestyle='-', lw=1.25, color='m', zorder=3, label = 'Nowcast Precision')

    for i in range(number_random_timeseries):
    
        precision_plot_random = random_precision_list[i]
            
        precision_plot_random= [precision_plot_random[i]*100.0 for i in range(len(precision_plot_random))]
        ax1.plot(precision_plot_random, threshold_reduced, linestyle='-', lw=2.0, color='cyan', zorder=1, alpha = 0.15)
        
    mean_curve_percent = [mean_random_precision[i]*100.0 for i in range(len(mean_random_precision))]
    ax1.plot(mean_curve_percent, threshold_reduced, linestyle='-', lw=0.75, color='k', zorder=2, label = 'Random Precision')
    
    random_upper_percent = [random_upper[i]*100.0 for i in range(len(random_upper))]
    random_lower_percent = [random_lower[i]*100.0 for i in range(len(random_lower))]

    ax1.plot(random_upper_percent, threshold_reduced, linestyle='dotted', lw=0.75, color='k', zorder=2, label = '1 $\sigma$ Confidence')
    ax1.plot(random_lower_percent, threshold_reduced, linestyle='dotted', lw=0.75, color='k', zorder=2)
    
        
#     
    #   Calculate uniform precision (number of time windows with a major earthquake) and associated self-information

    ax1.legend(loc = 'lower center', fontsize=6)
    
    ax1.tick_params(axis='both', labelsize=9)
    
    ax1.set_xlim(left=-5, right=105)
    
    Title_text = 'PPV Precision'
    plt.title(Title_text, fontsize=9)
    
    plt.xlabel('Probability (%)', fontsize = 9)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    plt.gca().invert_yaxis()
    
    plt.grid(linestyle = 'dotted', linewidth=0.5)
    
    ax1.minorticks_on()
    
    #
    #   =======================================================================
    #
    #
    #   Third plot: Information Entropy    
    
    ax2 = plt.subplot(gs[2])
#     frame1 = plt.gca()
    # 
    #   -------------------------------------------------------------
    #
                
    label_text = 'Nowcast Information'
    
    precision_info = [- math.log2(precision[i]) for i in range(len(precision))]
    ax2.plot(precision_info, threshold_reduced, linestyle='-', lw=1.25, color='m', zorder=1, label = label_text)
    
    for i in range(number_random_timeseries):
    
        precision_plot_random = random_precision_list[i]
        
        try:
            info_plot_random= [- math.log2(precision_plot_random[i]) for i in range(len(precision_plot_random))]
            ax2.plot(info_plot_random, threshold_reduced, linestyle='-', lw=2.0, color='cyan', zorder=1, alpha = 0.15)
        except:
            pass
        
    info_mean_curve = [- math.log2(mean_random_precision[i]) for i in range(len(mean_random_precision))]
    ax2.plot(info_mean_curve, threshold_reduced, linestyle='-', lw=0.75, color='k', zorder=2, label = 'Random Information')
    
    info_random_upper = [- math.log2(random_upper[i]) for i in range(len(random_upper))]
    info_random_lower = [- math.log2(random_lower[i]) for i in range(len(random_lower))]

    ax2.plot(info_random_upper, threshold_reduced, linestyle='dotted', lw=0.75, color='k', zorder=2, label = '1 $\sigma$ Confidence')
    ax2.plot(info_random_lower, threshold_reduced,  linestyle='dotted', lw=0.75, color='k', zorder=2)

#     ax2.set_xlim(left=-0.05, right=1.05)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    plt.gca().invert_yaxis()
    
    plt.grid(linestyle = 'dotted', linewidth=0.5)
    
    ax1.minorticks_on()
    
    ax2.legend(loc = 'lower center', fontsize=6)
    
    ax2.tick_params(axis='both', labelsize=9)
 
# 
#   -----------------------------------------------------------------
#
#     
    Title_text = 'PPV Information Entropy'
    plt.title(Title_text, fontsize=9)
    
    plt.xlabel('Self Information (Bits)', fontsize = 9)
   
    # Save figures
    
    figure_name = './Data/Timeseries_Precision_Information_' + 'TW' + str(forecast_interval) + '.png'
    plt.savefig(figure_name,dpi=150)
    
    plt.close()
    
    return 


    ######################################################################
    
def plot_event_timeseries(time_list_reduced, eqs_list_reduced, eqs_list_EMA_reduced, plot_start_year, mag_large_plot,\
        NELng_local, SWLng_local, NELat_local, SWLat_local, Location, NSteps, delta_time_interval, min_mag, lambda_mult):
#     
#
#   ------------------------------------------------------------
#

    year_large_eq, mag_large_eq, index_large_eq = SEISRCalcMethods.get_large_earthquakes(mag_large_plot,min_mag)
    
    
    fig, ax = plt.subplots()
    
    for j in range(len(eqs_list_reduced)):
    
        event_time = time_list_reduced[j] + 2.*delta_time_interval  #   adjustment to ensure correct event time registration
        x_eq = [event_time, event_time]
        y_eq = [0.,math.log(1.+eqs_list_reduced[j],10)]
#         y_eq = [0.,eqs_list_reduced[j]]
    
        ax.plot(x_eq,y_eq, linestyle='-', lw=0.5, color='c', zorder=5, alpha=0.30)
#         ax.plot(x_eq,y_eq, 'o', ms=2, color='b', zorder=5, alpha=0.70)
        
    ax.plot(x_eq,y_eq, linestyle='-', lw=0.5, color='c', zorder=5, alpha=0.30,label='Number M $\geq$ '+str(min_mag))

    time_list_adjusted  = [time_list_reduced[i] + 2.*delta_time_interval for i in range(len(time_list_reduced))]
    
    year_large_eq, mag_large_eq, index_large_eq = \
            SEISRCalcMethods.adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, time_list_adjusted, plot_start_year)
            
    log_eqs_list        = [math.log(1.+eqs_list_reduced[i],10) for i in range(len(eqs_list_reduced))]
    log_eqs_list_EMA    = [math.log(1.+eqs_list_EMA_reduced[i],10) for i in range(len(eqs_list_EMA_reduced))]

    ax.plot(time_list_adjusted,log_eqs_list_EMA, '--', color='b', lw=1.0, zorder=5, label='EMA')

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    #   -------------------------------------------------------------
    
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999  and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [0,log_eqs_list_EMA[index_large_eq[i]]]
            
            ax.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2)
            
    ax.plot(x_eq,y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2, label = '6.9 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.89999 and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [0,log_eqs_list_EMA[index_large_eq[i]]]
            
            ax.plot(x_eq, y_eq, linestyle='--', color='r', lw=0.7, zorder=2)
            
    ax.plot(x_eq,y_eq, linestyle='--', color='r', lw=0.7, zorder=2, label='M $\geq$ 6.9')

    #   -------------------------------------------------------------
    #
    #   If you want/don't want/ the bottom triangular markers, uncomment/comment the below
#     
    year_M6 = []
    time_M6 = []
    
    for i in range(len(year_large_eq)):
        x_eq = [year_large_eq[i], year_large_eq[i]]
        y_eq = [0,ymax]

        x_eq_mark = [year_large_eq[i]]
        y_eq_mark = [ymin]
                        
        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999  and float(year_large_eq[i]) >= plot_start_year:
            year_M6.append(year_large_eq[i])
            
            ax.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2)

    year_M7 = []
            
    for i in range(len(year_large_eq)):
    
        last_index = len(year_large_eq)-1
        x_eq = [year_large_eq[i], year_large_eq[i]]
        y_eq = [0,ymax]
        
        x_eq_mark = [year_large_eq[i]]
        y_eq_mark = [ymin]
            
        if float(mag_large_eq[i]) >= 6.89999 and float(year_large_eq[i]) >= plot_start_year:
            year_M7.append(year_large_eq[i])
   
            ax.plot(x_eq, y_eq, 'r', linestyle='--', lw=0.7, zorder=2)

#             ax.plot(x_eq_mark, y_eq_mark, 'v', color='r', ms=5, zorder=2)    
            
    y_M6 = [ymin for i in range(len(year_M6))]
    y_M7 = [ymin for i in range(len(year_M7))]

    ax.plot(year_M6, y_M6, 'v', color='k', ms=2, zorder=3, label = '6.9 $>$ M $\geq$ 6.0')
    ax.plot(year_M7, y_M7, 'v', color='r', ms=5, zorder=2, label='M $\geq$ 6.9')
    
    #   The below masks off the line extensions above - sloppy way of erasing them!
    
    max_plot_line = [ymax for i in range(len(time_list_adjusted))]
    
    ax.fill_between(time_list_adjusted, log_eqs_list_EMA , max_plot_line, color='w', alpha=1, zorder=4)
    
    #   -------------------------------------------------------------
    #
    ax.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'y')
    
    ax.legend(loc = 'upper right', fontsize=8)
    
    #     
    #   ------------------------------------------------------------
    #
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

#     textstr =   'EMA Samples (N): ' + str(NSteps) +\
#                 '\nTime Step: ' + str_time_interval +\
#                 '\n$M_{min}$: ' + str(round(min_mag,2))

    textstr =   'Time Increment: ' + str_time_interval +\
                '\nN for EMA: ' + str(NSteps) +\
                '\n$M_{min}$: ' + str(round(min_mag,2))

# 
#     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

#     # place a text box in upper left in axes coords
    ax.text(0.015, 0.980, textstr, transform=ax.transAxes, fontsize=8,
        verticalalignment='top', horizontalalignment = 'left', bbox=props, linespacing = 1.8, zorder=5)

#   ------------------------------------------------------------
#

    ax.minorticks_on()
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    SupTitle_text = 'Seismicity Rate($t$) vs. Time'

    plt.suptitle(SupTitle_text, fontsize=12, y = 0.96)
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location
            
    plt.title(Title_text, fontsize=9)
    
    plt.ylabel('$\Theta(t) = Log_{10}$ (1 + Monthly Number)', fontsize = 10)
    plt.xlabel('Time (Year)', fontsize = 10)
    
    data_string_title = 'EMA' + '_TTI' + str(test_time_interval) + \
            '_NSTP' + str(NSteps) + '_MM' + str(min_mag) + '_CF' + str(lambda_mult) 

    figure_name = './Data/Seismicity_' + data_string_title + '_' + str(plot_start_year) + '_' + str(plot_start_year) + '.png'
    plt.savefig(figure_name,dpi=600)
    
#     plt.show()
#     matplotlib.pyplot.close('all')
    plt.close('all')

    return 
    
    ######################################################################
    
def plot_event_timeseries_mean_eqs\
                (time_list_reduced, eqs_list_reduced, eqs_list_EMA_reduced,\
                timeseries, time_bins, date_bins,\
                plot_start_year, mag_large_plot, NELng_local, SWLng_local, NELat_local, SWLat_local, Location, \
                NSteps, delta_time_interval, min_mag, lambda_min_mult):
                
#
#   ------------------------------------------------------------
#
    year_large_eq, mag_large_eq, index_large_eq = SEISRCalcMethods.get_large_earthquakes(mag_large_plot,min_mag)
    
    fig, (ax1, ax2) = plt.subplots(2,1)
    
#
#   ------------------------------------------------------------
#
#   Seismicity Plot

    for j in range(len(eqs_list_reduced)):
    
        event_time = time_list_reduced[j] + 2.*delta_time_interval  #   adjustment to ensure correct event time registration
        x_eq = [event_time, event_time]
        y_eq = [0.,math.log(1.+eqs_list_reduced[j],10)]
#         y_eq = [0.,eqs_list_reduced[j]]
    
        ax1.plot(x_eq,y_eq, linestyle='-', lw=0.5, color='c', zorder=5, alpha=0.30)
#         ax.plot(x_eq,y_eq, 'o', ms=2, color='b', zorder=5, alpha=0.70)
        
    ax1.plot(x_eq,y_eq, linestyle='-', lw=0.5, color='c', zorder=5, alpha=0.30,label='Number M $\geq$ '+str(min_mag))

    time_list_adjusted  = [time_list_reduced[i] + 2.*delta_time_interval for i in range(len(time_list_reduced))]
    
    year_large_eq, mag_large_eq, index_large_eq = \
            SEISRCalcMethods.adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, time_list_adjusted, plot_start_year)
            
    log_eqs_list        = [math.log(1.+eqs_list_reduced[i],10) for i in range(len(eqs_list_reduced))]
    log_eqs_list_EMA    = [math.log(1.+eqs_list_EMA_reduced[i],10) for i in range(len(eqs_list_EMA_reduced))]

    ax1.plot(time_list_adjusted,log_eqs_list_EMA, '--', color='b', lw=1.0, zorder=5, label='EMA')

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    #   -------------------------------------------------------------
    
    for i in range(len(year_large_eq)):

#         if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999  and float(year_large_eq[i]) >= plot_start_year:

        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [0,log_eqs_list_EMA[index_large_eq[i]]]
            
            ax1.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2)
            
    ax1.plot(x_eq,y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2, label = '6.9 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_large_eq)):

#         if float(mag_large_eq[i]) >= 6.89999 and float(year_large_eq[i]) >= plot_start_year:

        if float(mag_large_eq[i]) >= 6.89999:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [0,log_eqs_list_EMA[index_large_eq[i]]]
            
            ax1.plot(x_eq, y_eq, linestyle='--', color='r', lw=0.7, zorder=2)
            
    ax1.plot(x_eq,y_eq, linestyle='--', color='r', lw=0.7, zorder=2, label='M $\geq$ 6.9')
    
    ax1.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    
    #
    #   ------------------------------------------------------------
    #   ------------------------------------------------------------
    #
    #   Mean EQs Plot
    #
    eqs_list = []
    
    for i in range(len(time_bins)):        #   Over all bins
        eq_sum = 0
        
        for j in range(len(timeseries)):
            eq_sum += timeseries[j][i]
            
        eqs_list.append(eq_sum)
    
    eq_means = []
    time_list= []
    
    eq_means_plot   =   []
    time_list_plot  =   []
    
    time_offset = 3.*delta_time_interval
#     time_offset = 0.
    
    for i in range(1,len(eqs_list)):
        try:
            eq_means.append(np.mean(eqs_list[:i]))
            time_list.append(time_bins[i])
        except:
            pass
            
            
    for i in range(len(time_list)):
        if (time_list[i]) > plot_start_year:
            eq_means_plot.append(eq_means[i])
            time_list_plot.append(time_list[i]-time_offset) #   Adjust times so everything lines up properly
            
            
    eq_means_plot  = eq_means_plot[5:]           #   Remove some of the events so that both plots have the same number of events
    time_list_plot = time_list_plot[5:]
    
    ax2.plot(time_list_plot, eq_means_plot, linestyle='-', lw=1.0, color='b', zorder=3, label='Mean $M$ > ' + str(min_mag))

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    #   ------------------------------------------------------------
    #
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

    textstr =   'Time Increment: ' + str_time_interval +\
                '\nEMA Samples (N): ' + str(NSteps) +\
                '\n$M_{min}$: ' + str(round(min_mag,2))
# 
#     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

#     # place a text box in upper left in axes coords
    ax1.text(0.015, 0.960, textstr, transform=ax1.transAxes, fontsize=7,
        verticalalignment='top', horizontalalignment = 'left', bbox=props, linespacing = 1.8, zorder=5)

   #   -------------------------------------------------------------
   
    year_large_eq, mag_large_eq, index_large_eq = \
            SEISRCalcMethods.adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, time_list_plot, time_list_plot[0])
            
    time_offset = 2.*delta_time_interval
    time_offset = 0.
    
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999 and float(time_list_plot[i]) > plot_start_year:
            x_eq = [year_large_eq[i]+ time_offset, year_large_eq[i]+time_offset]
            y_eq = [ymin,eq_means_plot[index_large_eq[i] ]]
            
            ax2.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2)
            
    ax2.plot(x_eq,y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2, label = '6.9 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.89999 and float(time_list_plot[i]) > plot_start_year:
            x_eq = [year_large_eq[i]+time_offset, year_large_eq[i]+time_offset]
            y_eq = [ymin,eq_means_plot[index_large_eq[i] ]]
            
            ax2.plot(x_eq, y_eq, linestyle='--', color='r', lw=0.7, zorder=2)
            
    ax2.plot(x_eq,y_eq, linestyle='--', color='r', lw=0.7, zorder=2, label='M $\geq$ 6.9')

    #   -------------------------------------------------------------
    
    min_plot_line = [ymin for i in range(len(time_list_plot))]
    ax2.fill_between(time_list_plot, min_plot_line, eq_means_plot, color='c', alpha=0.1, zorder=0)
    
    ax2.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    
    ax2.legend(loc = 'upper left', fontsize=7)
    #     
    #   ------------------------------------------------------------
    #
            
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'
        
    textstr =   'Time Step: ' + str_time_interval +\
                '\n$M_{min}$: ' + str(round(min_mag,2))
                
    #     
# 
#   ------------------------------------------------------------
#

    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    SupTitle_text = 'Seismicity Rate $S(t)$ vs. Time'
    plt.suptitle(SupTitle_text, fontsize=14, y = 0.96)
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location
    ax1.set_title(Title_text, fontsize=9)
    
    ax1.tick_params(axis='both', labelsize=7)
    ax2.tick_params(axis='both', labelsize=7)
    
    ax1.minorticks_on()
    ax2.minorticks_on()
    
    ax1.set_ylabel('$Log_{10}$ (1 + Monthly Number)', fontsize = 11)
    ax1.set_xlabel('', fontsize = 11)
        
    ax2.set_ylabel('$\mu(t)$ (Mean Number)', fontsize = 11)
    ax2.set_xlabel('Time (Year)', fontsize = 11)
    
    ax1.tick_params(axis='both', labelsize=10)
    ax2.tick_params(axis='both', labelsize=10)
    
    #   Save figure
    
    data_string_title = 'EMA' + '_TTI' + str(test_time_interval) + \
            '_NSTP' + str(NSteps) + '_MM' + str(min_mag) + '_CF' + str(lambda_min_mult) 

    figure_name = './Data/Seismicity_Mean_EQs_' + data_string_title + '_' +  str(plot_start_year) + '.png'
    plt.savefig(figure_name,dpi=600)
    
#     plt.show()
#     matplotlib.pyplot.close('all')
    plt.close('all')

    return 
    
    ######################################################################
    
def plot_precision_timeseries(time_list_reduced, log_number_reduced, \
        plot_start_year, mag_large_plot, mag_large, min_mag,\
        NELng_local, SWLng_local, NELat_local, SWLat_local, Location, NSteps, delta_time_interval, lambda_mult, min_rate,\
        forecast_interval, number_thresholds, threshold_value, \
        true_positive, false_positive, true_negative, false_negative, \
        true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate,\
        year_large_eq, mag_large_eq, index_large_eq):
        
    #
    #   ------------------------------------------------------------
    #
    
    fig, ax = plt.subplots()
    
    #  Compute the Precision
    
    threshold_reduced   =   []
    precision           =   []
    for i in range(1,len(true_positive)):
        numer = true_positive[i]
        denom = false_positive[i] + true_positive[i]
        threshold_reduced.append(threshold_value[i])

        precision.append(round(100.0*numer/denom,2))
        
    print(len(precision))
    print()
    
    #   Build Precision timeseries
    max_log_number = max(log_number_reduced)
    min_log_number = min(log_number_reduced)
    diff_value = max_log_number - min_log_number
    
    precision_timeseries = []
    
    for i in range(len(log_number_reduced)):    #   loop over time
        threshold_index = (len(precision))*(log_number_reduced[i] - min_log_number)/(diff_value)
        j = int(threshold_index)
        if j == len(precision):
            j -= 1
        
        precision_timeseries.append(precision[j])
        
    ax.plot(time_list_reduced, precision_timeseries, linestyle='-', lw=1.25, color='b', zorder=3)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    year_large_eq, mag_large_eq, index_large_eq = \
            SEISRCalcMethods.adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, time_list_reduced, plot_start_year)
            
   #   -------------------------------------------------------------

    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999  and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymin,precision_timeseries[index_large_eq[i]]]
            
            ax.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=1.0, zorder=2)
            
    ax.plot(x_eq,y_eq, linestyle='dotted', color='k', lw=1.0, zorder=2, label = '6.9 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.89999 and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymin,precision_timeseries[index_large_eq[i]]]
            
            ax.plot(x_eq, y_eq, linestyle='--', color='r', lw=1.0, zorder=2)
            
    ax.plot(x_eq,y_eq, linestyle='--', color='r', lw=1.0, zorder=2, label='M $\geq$ 6.9')

    #   -------------------------------------------------------------
    
    max_plot_line = [ymin for i in range(len(time_list_reduced))]
    ax.fill_between(time_list_reduced , max_plot_line, precision_timeseries, color='c', alpha=0.1, zorder=0)
    
#
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

    textstr =   'EMA Samples (N): ' + str(NSteps) +\
                '\n$M_{Large} \geq$' + str(mag_large) + \
                '\n$T_W$: ' + str(forecast_interval) + ' Years' +\
                '\nTime Step: ' + str_time_interval +\
                '\n$R_{min}$ = ' + str(int(round(min_rate,0))) +\
                '\n$M_{Min}$: ' + str(round(min_mag,2))

# 
#     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.55)

    ax.text(0.015, 0.715, textstr, transform=ax.transAxes, fontsize=8, bbox=props, linespacing = 1.8)

#   ------------------------------------------------------------
#

    ax.minorticks_on()
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    SupTitle_text = 'Nowcast Precision(%) vs. Time for '

    plt.suptitle(SupTitle_text, fontsize=12, y = 0.96)
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location
            
    plt.title(Title_text, fontsize=9)
    
    plt.ylabel('Precision (Of Current State, %)', fontsize = 12)
    plt.xlabel('Time (Year)', fontsize = 12)
    
    data_string_title = 'EMA' + '_FI' + str(forecast_interval) + '_TTI' + str(test_time_interval) + \
            '_NSTP' + str(NSteps) + '_MM' + str(min_mag) + '_CF' + str(lambda_mult) 

    figure_name = './Data/Precision_Timeseries_' + data_string_title + '.png'
    plt.savefig(figure_name,dpi=600)
    
    plt.close()
    
    return 


    ######################################################################
    
def plot_temporal_ROC(values_window, times_window, true_positive, false_positive, true_negative, false_negative, \
                    threshold_value, forecast_interval, mag_large, min_mag, plot_start_year,\
                    data_string_title, number_thresholds, NELng_local, SWLng_local, NELat_local, SWLat_local, \
                    Grid, Location, NSteps, delta_time_interval, lambda_mult, min_rate):
                    
# 
#   ------------------------------------------------------------
#
#   Plot ROC and random ROCs

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                SEISRCalcMethods.compute_ROC_rates(true_positive, false_positive, true_negative, false_negative)   
                
    info_tp, info_fp, info_random, info_roc, mean_tpr, mean_fpr = SEISRCalcMethods.calc_ROC_information_entropy\
                (threshold_value, true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate)
                
    js_divergence, kl_divergence = SEISRCalcMethods.jensen_shannon_divergence\
                (true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate)

    number_random_timeseries = 200
    
    fig, ax = plt.subplots()

    label_text = 'ROC for $M\geq$'+ str(mag_large) 

    ax.plot(false_positive_rate, true_positive_rate, linestyle='-', lw=1.0, color='r', zorder=3, label = label_text)
    
    ax.minorticks_on()
        
    x_line = [0.,1.]
    y_line = [0.,1.]
    
    ax.plot(x_line, y_line, linestyle='-', lw=1.0, color='k', zorder=2, label = 'Random Mean')
    
    random_true_positive_rate_list = [[] for i in range(number_thresholds)]
    
    for i in range(number_random_timeseries):
    
        random_values = SEISRCalcMethods.random_timeseries(values_window, times_window)
        
        true_positive_random, false_positive_random, true_negative_random, false_negative_random, threshold_value_random = \
                SEISRCalcMethods.compute_ROC(times_window, random_values, forecast_interval, mag_large, min_mag, \
                number_thresholds, number_random_timeseries, i+1)
                
        true_positive_rate_random, false_positive_rate_random, false_negative_rate_random, true_negative_rate_random = \
                SEISRCalcMethods.compute_ROC_rates(true_positive_random, false_positive_random, true_negative_random, false_negative_random)   
            
        for j in range(len(true_positive_rate_random)):
            random_true_positive_rate_list[j].append(true_positive_rate_random[j])
        
        ax.plot(false_positive_rate_random, true_positive_rate_random, linestyle='-', lw=2.0, color='cyan', zorder=1, alpha = 0.15)
# 
#   ------------------------------------------------------------
#        
    stddev_curve    =   []
    for i in range(len(random_true_positive_rate_list)):
        stddev_curve.append(np.std(random_true_positive_rate_list[i]))
        
    random_upper = []
    random_lower = []
    
    for i in range(number_thresholds):
        random_upper.append(false_positive_rate_random[i] + stddev_curve[i])
        random_lower.append(false_positive_rate_random[i] - stddev_curve[i])
        
    ax.plot(false_positive_rate_random, random_upper, linestyle='dotted', lw=0.75, color='k', zorder=2, label = '1 $\sigma$ Confidence')
    ax.plot(false_positive_rate_random, random_lower, linestyle='dotted', lw=0.75, color='k', zorder=2)
         
# 
#   ------------------------------------------------------------
#
    skill_score =   trapz(true_positive_rate, false_positive_rate)  #   Use the trapezoidal integration rule
    
    skill_score_upper    =   trapz(random_upper,false_positive_rate_random)
    skill_score_lower    =   trapz(random_lower,false_positive_rate_random)

    stddev_skill_score = 0.5*(abs(skill_score_upper- 0.5) + abs(skill_score_lower - 0.5))
    
    print()
    print('--------------------------------------')
    print()
    print('Skill Score: ', round(skill_score,3))
    print()
    print('Skill Score Random: ', '0.5 +/- ' + str(round(stddev_skill_score,3) ))
    print()
    print('--------------------------------------')
    print()
# 
    ax.legend(bbox_to_anchor=(0, 1), loc ='upper left', fontsize=8)
    ax.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
# 
#   ------------------------------------------------------------
#

    relative_skill = abs(skill_score - 0.5)
    
    skill_index = - 100.0 * (relative_skill * math.log2(relative_skill) + (1.-relative_skill) * math.log2(1.0-relative_skill)  )

#     skill_score = sum(hit_bins)/float(len(hit_bins))
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

    textstr =       'Skill Score = ' + str(round(skill_score,2)) + \
                    '\nSkill Index = ' + str(round(skill_index,2)) + '%'\
                    '\n$T_W$ = ' + str(forecast_interval) + ' Years'+\
                    '\n$I_{ROC}$ = ' + str(round(info_tp,2)) + ' Bits' +\
                    '\n$I_{Random}$ = ' + str(round(info_random, 2)) + ' Bits' +\
                    '\n$JSDiv$ = ' + str(round(js_divergence, 2)) + ' Bits' +\
                    '\n$KLDiv$ = ' + str(round(kl_divergence, 2)) + ' Bits' +\
                    '\nEMA Samples (N): ' + str(NSteps) +\
                    '\nTime Step: ' + str_time_interval +\
                    '\n$R_{min}$: ' + str(round(min_rate,0)) +\
                    '\nTarget Mag: ' + str(round(mag_large,2)) +\
                    '\n$M_{min}$: ' + str(round(min_mag,2))


    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.5)
# 
    # place a text box in bottom right in axes coords
    ax.text(0.975, 0.025, textstr, transform=ax.transAxes, fontsize=8,
        verticalalignment='bottom', horizontalalignment = 'right', bbox=props, linespacing = 1.8)
    
    SupTitle_text = 'Receiver Operating Characteristic'
    plt.suptitle(SupTitle_text, fontsize=12, y = 0.96)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location 
    plt.title(Title_text, fontsize=8)
    
    plt.ylabel('Hit Rate (TPR)', fontsize = 12)
    plt.xlabel('False Alarm Rate (FPR)', fontsize = 12)
    
    figure_name = 'Predictions/ROC_M' + str(mag_large) + '_FI' + str(forecast_interval) + '_' + str(plot_start_year) + '.png'
    
    plt.savefig(figure_name,dpi=300)
#     plt.show()
        
    return

    ##############################################r########################
    
def plot_temporal_ROC_shaded(values_window, times_window, true_positive, false_positive, true_negative, false_negative, \
                    threshold_value, forecast_interval, mag_large, min_mag, plot_start_year,\
                    data_string_title, number_thresholds, NELng_local, SWLng_local, NELat_local, SWLat_local, \
                    Grid, Location, NSteps, delta_time_interval, lambda_mult, min_rate):
                    
# 
#   ------------------------------------------------------------
#
#   Plot ROC and random ROCs

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                SEISRCalcMethods.compute_ROC_rates(true_positive, false_positive, true_negative, false_negative)   
                
    info_tp, info_fp, info_random, info_roc, mean_tpr, mean_fpr = SEISRCalcMethods.calc_ROC_information_entropy\
                (threshold_value, true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate)
                
    js_divergence, kl_divergence = SEISRCalcMethods.jensen_shannon_divergence\
                (true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate)

    fig, ax = plt.subplots()

    label_text = 'ROC for $M\geq$'+ str(mag_large) 

    ax.plot(false_positive_rate, true_positive_rate, linestyle='-', lw=1.0, color='r', zorder=3, label = label_text)
    
    xmin,xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    min_plot_line = [0. for i in range(len(false_positive_rate))]
    random_line = [false_positive_rate[i] for i in range(len(false_positive_rate))]
    
    ax.fill_between( false_positive_rate, min_plot_line, random_line, color='c', alpha=0.1, zorder=0)
    ax.fill_between( false_positive_rate, random_line, true_positive_rate, color='lightgreen', alpha=0.1, zorder=0)
    
    ax.minorticks_on()
        
    x_line = [0.,1.]
    y_line = [0.,1.]
    
    ax.plot(x_line, y_line, linestyle='-', lw=1.0, color='k', zorder=2, label = 'Random Mean')
    
# 
#   ------------------------------------------------------------
#
    skill_score =   trapz(true_positive_rate, false_positive_rate)  #   Use the trapezoidal integration rule
    
    print()
    print('--------------------------------------')
    print()
    print('Skill Score: ', round(skill_score,3))
    print()
    print('--------------------------------------')
    print()
# 
    ax.legend(bbox_to_anchor=(0, 1), loc ='upper left', fontsize=8)
    ax.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
# 
#   ------------------------------------------------------------
#

    relative_skill = abs(skill_score - 0.5)
    
    skill_index = - 100.0 * (relative_skill * math.log2(relative_skill) + (1.-relative_skill) * math.log2(1.0-relative_skill)  )

#     skill_score = sum(hit_bins)/float(len(hit_bins))
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

    textstr =       'Skill Score = ' + str(round(skill_score,2)) + \
                    '\nSkill Index = ' + str(round(skill_index,2)) + '%'\
                    '\n$T_W$ = ' + str(forecast_interval) + ' Years'+\
                    '\n$I_{ROC}$ = ' + str(round(info_tp,2)) + ' Bits' +\
                    '\n$I_{Random}$ = ' + str(round(info_random, 2)) + ' Bits' +\
                    '\n$JSDiv$ = ' + str(round(js_divergence, 2)) + ' Bits' +\
                    '\n$KLDiv$ = ' + str(round(kl_divergence, 2)) + ' Bits' +\
                    '\nEMA Samples (N): ' + str(NSteps) +\
                    '\nTime Step: ' + str_time_interval +\
                    '\n$R_{min}$: ' + str(round(min_rate,0)) +\
                    '\nTarget Mag: ' + str(round(mag_large,2)) +\
                    '\n$M_{min}$: ' + str(round(min_mag,2))


    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.5)
# 
    # place a text box in bottom right in axes coords
    ax.text(0.975, 0.025, textstr, transform=ax.transAxes, fontsize=8,
        verticalalignment='bottom', horizontalalignment = 'right', bbox=props, linespacing = 1.8)
#         
    SupTitle_text = 'Receiver Operating Characteristic'
    plt.suptitle(SupTitle_text, fontsize=14, y = 0.96)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location 
    plt.title(Title_text, fontsize=8)
    
    plt.ylabel('Hit Rate (TPR)', fontsize = 12)
    plt.xlabel('False Alarm Rate (FPR)', fontsize = 12)
    
    figure_name = 'Predictions/Shaded_ROC_M_' + str(mag_large) + '_FI' + str(forecast_interval) + '_' + str(plot_start_year) + '.png'
    
    plt.savefig(figure_name,dpi=300)
#     plt.show()
        
    return

    ##############################################r########################
    
def plot_temporal_TPR_FPR_Threshold(values_window, times_window, true_positive, false_positive, true_negative, false_negative, \
                    threshold_value, forecast_interval, mag_large, min_mag, plot_start_year,\
                    data_string_title, number_thresholds, NELng_local, SWLng_local, NELat_local, SWLat_local, \
                    Grid, Location, NSteps, delta_time_interval, lambda_mult, min_rate):
                    
# 
#   ------------------------------------------------------------
#
#   Plot ROC and random ROCs

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                SEISRCalcMethods.compute_ROC_rates(true_positive, false_positive, true_negative, false_negative)   
                
    info_tp, info_fp, info_random, info_roc, mean_tpr, mean_fpr = SEISRCalcMethods.calc_ROC_information_entropy\
                (threshold_value, true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate)
                
    js_divergence, kl_divergence = SEISRCalcMethods.jensen_shannon_divergence\
                (true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate)

    
    fig, ax = plt.subplots()

    label_text = 'ROC for $M\geq$'+ str(mag_large) 

    ax.plot(threshold_value, true_positive_rate, linestyle='-', lw=1.0, color='r', zorder=3, label = 'True Positive Rate')
    ax.plot(threshold_value, false_positive_rate, linestyle='-', lw=1.0, color='b', zorder=3, label = 'False Positive Rate')
    
    ax.minorticks_on()
    
    last_index = len(threshold_value) -1
    
    x_line = [threshold_value[0], threshold_value[last_index]]
    y_line = [true_positive_rate[0],true_positive_rate[last_index]]
    
    ax.plot(x_line, y_line, linestyle='-', lw=1.0, color='k', zorder=2, label = 'Random Rate')
    
    poisson_curve_tpr = []
    for i in range(len(threshold_value)):
        poisson_value = 1. - math.exp(-(threshold_value[i]-threshold_value[0])/mean_tpr)
        poisson_curve_tpr.append(poisson_value)
        
    ax.plot(threshold_value, poisson_curve_tpr, linestyle='--', lw=0.5, color='r', zorder=2, label = 'Poisson TPR')
    
    poisson_curve_fpr = []
    for i in range(len(threshold_value)):
        poisson_value = 1. - math.exp(-(threshold_value[i]-threshold_value[0])/mean_fpr)
        poisson_curve_fpr.append(poisson_value)
        
    ax.plot(threshold_value, poisson_curve_fpr, linestyle='--', lw=0.5, color='b', zorder=2, label = 'Poisson FPR')
    
# 
#   ------------------------------------------------------------
#
    skill_score =   trapz(true_positive_rate, false_positive_rate)  #   Use the trapezoidal integration rule
    
    print()
    print('--------------------------------------')
    print()
    print('Skill Score: ', round(skill_score,3))
    print()
    print('--------------------------------------')
    print()
# 
    ax.legend(bbox_to_anchor=(0, 1), loc ='upper left', fontsize=8)
    ax.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
# 
#   ------------------------------------------------------------
#

    relative_skill = abs(skill_score - 0.5)
    
    skill_index = - 100.0 * (relative_skill * math.log2(relative_skill) + (1.-relative_skill) * math.log2(1.0-relative_skill)  )

#     skill_score = sum(hit_bins)/float(len(hit_bins))
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

    textstr =       'Skill Score = ' + str(round(skill_score,2)) + \
                    '\nSkill Index = ' + str(round(skill_index,2)) + '%'\
                    '\n$T_W$ = ' + str(forecast_interval) + ' Years'+\
                    '\n$I_{ROC}$ = ' + str(round(info_tp,2)) + ' Bits' +\
                    '\n$I_{Random}$ = ' + str(round(info_random, 2)) + ' Bits' +\
                    '\n$JSDiv$ = ' + str(round(js_divergence, 2)) + ' Bits' +\
                    '\n$KLDiv$ = ' + str(round(kl_divergence, 2)) + ' Bits' +\
                    '\nEMA Samples (N): ' + str(NSteps) +\
                    '\nTime Step: ' + str_time_interval +\
                    '\n$R_{min}$: ' + str(round(min_rate,0)) +\
                    '\nTarget Mag: ' + str(round(mag_large,2)) +\
                    '\n$M_{min}$: ' + str(round(min_mag,2))


    # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.5)
# 
    # place a text box in bottom right in axes coords
    ax.text(0.975, 0.025, textstr, transform=ax.transAxes, fontsize=8,
        verticalalignment='bottom', horizontalalignment = 'right', bbox=props, linespacing = 1.8)
    
    SupTitle_text = 'Statistical Rate Distributions vs. State Variable'
    plt.suptitle(SupTitle_text, fontsize=12, y = 0.96)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location 
    plt.title(Title_text, fontsize=8)
    
    plt.ylabel('TPR / FPR / Random Rate', fontsize = 12)
    plt.xlabel('$\Theta(t) = Log_{10}$ (1 + Monthly Number)', fontsize = 12)
    
    figure_name = 'Predictions/TPR-FPR-Threshold' + str(mag_large) + '_FI' + str(forecast_interval) + '_' + str(plot_start_year) + '.png'
    
    plt.savefig(figure_name,dpi=300)
#     plt.show()
        
    return

    ##############################################r########################
 
def plot_precision_threshold(values_window, times_window, true_positive, false_positive, true_negative, false_negative, \
                    threshold_value, forecast_interval, mag_large, min_mag, plot_start_year,\
                    data_string_title, number_thresholds, NELng_local, SWLng_local, NELat_local, SWLat_local, \
                    Grid, Location, NStep, delta_time_interval, NSteps, lambda_mult, min_rate):
# 
#   ------------------------------------------------------------
#
#   Plot ROC and random ROCs

    true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                SEISRCalcMethods.compute_ROC_rates(true_positive, false_positive, true_negative, false_negative)   
                
    number_random_timeseries = 2
                
    precision, precision_info, threshold_reduced = SEISRCalcMethods.calc_precision_threshold\
            (true_positive, false_positive, false_negative, true_negative, threshold_value)
                
    fig, ax = plt.subplots()

    label_text = 'Precision for $M\geq$'+ str(mag_large)

    precision = [precision[i]*100.0 for i in range(len(precision))]

    ax.plot(threshold_reduced, precision, linestyle='-', lw=1.0, color='r', zorder=3, label = label_text)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    plt.gca().invert_xaxis()
    
    ax.set_ylim(bottom=ymin-2, top=ymax+2)
    
    plt.grid(linestyle = 'dotted', linewidth=0.5)
    
    ax.minorticks_on()
        
#   -------------------------------------------------

#   Plot all the random precision curves

#     
    random_precision_list, mean_random_precision, random_upper, random_lower = \
            SEISRCalcMethods.calc_random_precision_threshold\
            (precision, values_window, times_window, forecast_interval, mag_large, min_mag,\
            number_thresholds, number_random_timeseries)
    
    for i in range(number_random_timeseries):
    
        precision_plot_random = random_precision_list[i]
            
        precision_plot_random= [precision_plot_random[i]*100.0 for i in range(len(precision_plot_random))]
        ax.plot(threshold_reduced, precision_plot_random, linestyle='-', lw=2.0, color='cyan', zorder=1, alpha = 0.15)
        
    mean_curve = [mean_random_precision[i]*100.0 for i in range(len(mean_random_precision))]
    ax.plot(threshold_reduced, mean_curve, linestyle='-', lw=0.75, color='k', zorder=2, label = 'Random Mean')
    
    random_upper = [random_upper[i]*100.0 for i in range(len(random_upper))]
    random_lower = [random_lower[i]*100.0 for i in range(len(random_lower))]

    ax.plot(threshold_reduced, random_upper, linestyle='dotted', lw=0.75, color='k', zorder=2, label = '1 $\sigma$ Confidence')
    ax.plot(threshold_reduced, random_lower, linestyle='dotted', lw=0.75, color='k', zorder=2)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    ax.set_ylim(bottom=ymin-5, top=ymax)
#          
# 
#   ------------------------------------------------------------
#
# 
    xmin,xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
# 
#   ------------------------------------------------------------
#
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

    textstr =  '$T_W$ = ' + str(forecast_interval) + ' Years'+\
                    '\nEMA Samples (N): ' + str(NSteps) +\
                    '\nTime Step: ' + str_time_interval +\
                    '\n$R_{min}$: ' + str(round(min_rate,0)) +\
                    '\n$M_{min}$: ' + str(round(min_mag,2))

    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.5)
# 
    # place a text box in bottom right in axes coords
    ax.text(0.02, 0.5, textstr, transform=ax.transAxes, fontsize=8,
        verticalalignment='center', horizontalalignment = 'left', bbox=props, linespacing = 1.8)

    leg = ax.legend(loc = 'upper left', fontsize=8)
#     leg.set_title(title= legend_title_text,  prop={'size': 8})
    
# 
#   ------------------------------------------------------------
#
    SupTitle_text = 'Precision: Chance of a Correct Prediction'
    plt.suptitle(SupTitle_text, fontsize=12, y = 0.96)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location
    plt.title(Title_text, fontsize=9)
    
    plt.ylabel('Precision - PPV (%)', fontsize = 12)
    plt.xlabel('$\Theta(t) = Log_{10}$ (1 + Monthly Number)', fontsize = 12)
    
    figure_name = 'Predictions/Precision_v_Threshold_M' + str(mag_large) + '_FI' + str(forecast_interval) + '_' + str(plot_start_year)+ '.png'
    plt.savefig(figure_name,dpi=300)
#     plt.show()
        
    return

    ######################################################################
    
def plot_timeseries_precision_movie(time_list_reduced, log_number_reduced, \
        plot_start_year, mag_large_plot, mag_large, min_mag,\
        NELng_local, SWLng_local, NELat_local, SWLat_local, Location, NSteps, delta_time_interval, lambda_mult, min_rate,\
        forecast_interval, number_thresholds, threshold_value, \
        true_positive, false_positive, true_negative, false_negative, \
        true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate,\
        year_large_eq, mag_large_eq, index_large_eq,\
        index_movie, date_bins_reduced):
        
    #
    #   ------------------------------------------------------------
    #
    #  Set up the plots

    fig = plt.figure(figsize=(10, 6))        #   Define large figure and thermometer - 4 axes needed

    gs = gridspec.GridSpec(1,2,width_ratios=[15, 5], wspace = 0.2) 
    ax0 = plt.subplot(gs[0])
    
    #
    #   =======================================================================
    #
    #   First get the large earthquakes
    #
    #
    #   -------------------------------------------------------------
#     fig, ax = plt.subplots()
    
    ax0.plot(time_list_reduced,log_number_reduced, linestyle='-', lw=1.0, color='b', zorder=3)

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    year_large_eq, mag_large_eq, index_large_eq = \
            SEISRCalcMethods.adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, time_list_reduced, plot_start_year)
            
   #   -------------------------------------------------------------

    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999  and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymax,log_number_reduced[index_large_eq[i]]]
            
            ax0.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2)
            
    ax0.plot(x_eq,y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2, label = '6.9 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.89999 and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymax,log_number_reduced[index_large_eq[i]]]
            
            ax0.plot(x_eq, y_eq, linestyle='--', color='r', lw=0.7, zorder=2)
            
    ax0.plot(x_eq,y_eq, linestyle='--', color='r', lw=0.7, zorder=2, label='M $\geq$ 6.9')

    #   -------------------------------------------------------------
    
    min_plot_line = [ymax for i in range(len(time_list_reduced))]
    ax0.fill_between(time_list_reduced , min_plot_line, log_number_reduced, color='c', alpha=0.1, zorder=0)
    
    plt.gca().invert_yaxis()
            
    ax0.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    
    ax0.legend(loc = 'upper left', fontsize=8)
    
    #  
    #   ------------------------------------------------------------

    current_time     = time_list_reduced[index_movie]
    current_log_number      = log_number_reduced[index_movie]
    
    ax0.plot(current_time,current_log_number, 'ro', ms=6, zorder=4)
    #     
    #   -------------------------------------------------------------
    #
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

    textstr =   'EMA Samples (N): ' + str(NSteps) +\
                '\nTime Step: ' + str_time_interval +\
                '\n$R_{min}$: ' + str(round(min_rate,0))+\
                '\n$M_{min}$: ' + str(round(min_mag,2))
 
    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    #     # place a text box in upper left in axes coords
    ax0.text(0.015, 0.02, textstr, transform=ax0.transAxes, fontsize=8,
        verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)
        
    #     
    #   -------------------------------------------------------------
    #

#     textstr =   'Date: ' + str(round(time_list_reduced[index_seisr],3))
    textstr =   'Date: ' + str(date_bins_reduced[index_movie])
 
    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    #     # place a text box in upper left in axes coords
    ax0.text(0.5, 0.98, textstr, transform=ax0.transAxes, fontsize=10,
        verticalalignment='top', horizontalalignment = 'center', bbox=props, linespacing = 1.8)
        
    #     
    #   -------------------------------------------------------------
    #
    ax0.minorticks_on()
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    SupTitle_text = 'Seismicity: ' + str(NSteps) + ' Month Exponential Moving Average'

    plt.suptitle(SupTitle_text, fontsize=12, y = 0.97)
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location\
            + ' (Note Y-Axis is Inverted)'
            
    plt.title(Title_text, fontsize=9)

    plt.ylabel('$\Theta(t) = Log_{10}$ (1 + Monthly Number)', fontsize = 12)
    plt.xlabel('Time (Year)', fontsize = 8)
    
    #
    #   =======================================================================
    #
    #   Second plot: Precision    
    
    ax1 = plt.subplot(gs[1])
    frame1 = plt.gca()
    # 
    #   -------------------------------------------------------------
    #
    #   Plot ROC and random ROCs

                
    #   Might have to create a list with the threshold values in it
    
    threshold_reduced   =   []
    precision           =   []
    for i in range(1,len(true_positive)):
        numer = true_positive[i]
        denom = false_positive[i] + true_positive[i]
        threshold_reduced.append(threshold_value[i])
#         print(i, numer, denom)
        precision.append(numer/denom)
    
    index_PPV = (current_log_number - min(log_number_reduced)) /(max(log_number_reduced) - min(log_number_reduced))
    index_PPV = int(index_PPV * (len(true_positive)-1))
    
    if index_PPV > len(precision)-1:
        index_PPV = len(precision)-1
        
    current_PPV = 100*precision[index_PPV]
    print('current_PPV', round(current_PPV,2))
        
    label_text = 'Precision for M'+ str(mag_large)

    precision = [precision[i]*100.0 for i in range(len(precision))]

    ax1.plot(precision, threshold_reduced, linestyle='-', lw=1.25, color='m', zorder=3, label = label_text)
    
    xmin,xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    x_line = [current_PPV, current_PPV]
    y_line = [current_log_number, min(log_number_reduced)]

    
    
    x_line = [current_PPV, min(precision)]
    y_line = [current_log_number, current_log_number]
    
    
    ax1.plot(current_PPV, current_log_number, 'ro', ms=6, zorder=4)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    plt.gca().invert_yaxis()
    
    plt.grid(linestyle = 'dotted', linewidth=0.5)
    
    ax1.minorticks_on()
    
    xmin,xmax = plt.xlim()
    ymin, ymax = plt.ylim()
 
    # 
    #   -------------------------------------------------------------
    #
    
    alphabox=0.5
    
    alert_color = 'w'
        
    if current_PPV >40:
        alert_color = 'deepskyblue'
        
    if current_PPV >50:
        alert_color = 'lime'
        
    if current_PPV >60:
        alert_color = 'yellow'
        
    if current_PPV >70:
        alert_color = 'orange'
        
    if current_PPV >80:
        alert_color = 'orangered'
        
    if current_PPV >90:
        alert_color = 'red'
        alphabox = 0.75

    textstr =   str(round(current_PPV,1)) + '%'
 
    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor=alert_color, edgecolor = 'k', alpha=alphabox)

    #     # place a text box in upper left in axes coords
    ax1.text(0.05, 0.98, textstr, transform=ax1.transAxes, fontsize=12,
        verticalalignment='top', horizontalalignment = 'left', bbox=props, linespacing = 1.4)
            
    ax1.plot(current_PPV, ymin, 'rv', ms=10, zorder=4)
        
# 
#   -----------------------------------------------------------------
#


#     
    Title_text = 'Chance of an M$\geq$' + str(mag_large) + ' Earthquake ' + '\nWithin ' + str(round(forecast_interval,1)) + ' Years (PPV)'
    plt.title(Title_text, fontsize=9)
    
    plt.xlabel('Precision - PPV (%)', fontsize = 12)
    plt.ylabel('$\Theta(t) = Log_{10}$ (1 + Monthly Number)', fontsize = 12)
   
    # Save figures
    
    figure_name = './DataMoviesPPV/Timeseries_Precision_000' + str(index_movie) + '.png'
    plt.savefig(figure_name,dpi=150)
    
    plt.close()
    
    return 


    ######################################################################
    
def plot_timeseries_accuracy_movie(time_list_reduced, log_number_reduced, \
        plot_start_year, mag_large_plot, mag_large, min_mag,\
        NELng_local, SWLng_local, NELat_local, SWLat_local, Location, NSteps, delta_time_interval, lambda_mult, min_rate,\
        forecast_interval, number_thresholds, threshold_value, \
        true_positive, false_positive, true_negative, false_negative, \
        true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate,\
        year_large_eq, mag_large_eq, index_large_eq,\
        index_movie, date_bins_reduced):
        
    #
    #   ------------------------------------------------------------
    #
    #  Set up the plots

    fig = plt.figure(figsize=(10, 6))        #   Define large figure and thermometer - 4 axes needed

    gs = gridspec.GridSpec(1,2,width_ratios=[15, 5], wspace = 0.2) 
    ax0 = plt.subplot(gs[0])
    
    #
    #   =======================================================================
    #
    ax0.plot(time_list_reduced,log_number_reduced, linestyle='-', lw=1.0, color='b', zorder=3)

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    year_large_eq, mag_large_eq, index_large_eq = \
            SEISRCalcMethods.adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, time_list_reduced, plot_start_year)
            
   #   -------------------------------------------------------------

    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999  and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymax,log_number_reduced[index_large_eq[i]]]
            
            ax0.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2)
            
    ax0.plot(x_eq,y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2, label = '6.9 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.89999 and float(year_large_eq[i]) >= plot_start_year:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymax,log_number_reduced[index_large_eq[i]]]
            
            ax0.plot(x_eq, y_eq, linestyle='--', color='r', lw=0.7, zorder=2)
            
    ax0.plot(x_eq,y_eq, linestyle='--', color='r', lw=0.7, zorder=2, label='M $\geq$ 6.9')

    #   -------------------------------------------------------------
    
    min_plot_line = [ymax for i in range(len(time_list_reduced))]
    ax0.fill_between(time_list_reduced , min_plot_line, log_number_reduced, color='c', alpha=0.1, zorder=0)
    
    plt.gca().invert_yaxis()
            
    ax0.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    
    ax0.legend(loc = 'upper left', fontsize=8)
    
    #  
    #   ------------------------------------------------------------

    current_time     = time_list_reduced[index_movie]
    current_log_number      = log_number_reduced[index_movie]
    
    ax0.plot(current_time,current_log_number, 'ro', ms=6, zorder=4)
    #     
    #   -------------------------------------------------------------
    #
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'

    textstr =   'EMA Samples (N): ' + str(NSteps) +\
                '\nTime Step: ' + str_time_interval +\
                '\n$R_{min}$: ' + str(round(min_rate,0))+\
                '\n$M_{min}$: ' + str(round(min_mag,2))
 
    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    #     # place a text box in upper left in axes coords
    ax0.text(0.015, 0.02, textstr, transform=ax0.transAxes, fontsize=8,
        verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)
        
    #     
    #   -------------------------------------------------------------
    #

    textstr =   'Date: ' + str(date_bins_reduced[index_movie])
 
 
    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    #     # place a text box in upper left in axes coords
    ax0.text(0.5, 0.98, textstr, transform=ax0.transAxes, fontsize=10,
        verticalalignment='top', horizontalalignment = 'center', bbox=props, linespacing = 1.8)
        
    #     
    #   -------------------------------------------------------------
    #
    ax0.minorticks_on()
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    SupTitle_text = 'Seismicity: ' + str(NSteps) + ' Month Exponential Moving Average'

    plt.suptitle(SupTitle_text, fontsize=12, y = 0.97)
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location\
            + ' (Note Y-Axis is Inverted)'
            
    plt.title(Title_text, fontsize=9)
    
    plt.ylabel('$\Theta(t) = Log_{10}$ (1 + Monthly Number)', fontsize = 12)
    plt.xlabel('Time (Year)', fontsize = 12)
    
    #
    #   =======================================================================
    #
    #   Second plot: Precision    
    
    ax1 = plt.subplot(gs[1])
    frame1 = plt.gca()
    # 
    #   -------------------------------------------------------------
    #
    #   Plot ROC and random ROCs

    accuracy = []
    for i in range(len(true_positive)):
        numer = true_positive[i] + true_negative[i]
        denom = true_positive[i] + true_negative[i] + false_positive[i] + false_negative[i]
        accuracy.append(numer/denom)
        
    index_ACC = (current_log_number - min(log_number_reduced)) /(max(log_number_reduced) - min(log_number_reduced))
    index_ACC = int(index_ACC * (len(true_positive)-1))
    
    current_ACC = 100*accuracy[index_ACC]
    print('current_ACC', round(current_ACC,2))
        
    label_text = 'Accuracy for M'+ str(mag_large)

    accuracy = [accuracy[i]*100.0 for i in range(len(accuracy))]

    ax1.plot(accuracy, threshold_value, linestyle='-', lw=1.25, color='m', zorder=3, label = label_text)
    
    xmin,xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    x_line = [current_ACC, current_ACC]
    y_line = [current_log_number, min(log_number_reduced)]

    
    x_line = [current_ACC, min(accuracy)]
    y_line = [current_log_number, current_log_number]
    

    ax1.plot(current_ACC, current_log_number, 'ro', ms=6, zorder=4)
    
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
    plt.gca().invert_yaxis()
    
    plt.grid(linestyle = 'dotted', linewidth=0.5)
    
    ax1.minorticks_on()
    
    xmin,xmax = plt.xlim()
    ymin, ymax = plt.ylim()
 
    # 
    #   -------------------------------------------------------------
    #
    
    alphabox=0.5
    
    alert_color = 'w'
        
    if current_ACC >40:
        alert_color = 'deepskyblue'
        
    if current_ACC >50:
        alert_color = 'lime'
        
    if current_ACC >60:
        alert_color = 'yellow'
        
    if current_ACC >70:
        alert_color = 'orange'
        
    if current_ACC >80:
        alert_color = 'orangered'
        
    if current_ACC >90:
        alert_color = 'red'
        alphabox = 0.75

    textstr =   str(round(current_ACC,1)) + '%'
 
    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor=alert_color, edgecolor = 'k', alpha=alphabox)

    #     # place a text box in upper left in axes coords
    ax1.text(0.05, 0.98, textstr, transform=ax1.transAxes, fontsize=12,
        verticalalignment='top', horizontalalignment = 'left', bbox=props, linespacing = 1.4)
            
    ax1.plot(current_ACC, ymin, 'rv', ms=10, zorder=4)
        
# 
#   -----------------------------------------------------------------
#

#     
    Title_text = 'Accuracy for M$\geq$' + str(mag_large) + ' Earthquake ' + '\nWithin ' + str(round(forecast_interval,1)) + ' Years (ACC)'
    plt.title(Title_text, fontsize=9)
    
    plt.xlabel('Accuracy - ACC (%)', fontsize = 12)
    plt.ylabel('$\Theta(t) = Log_{10}$ (1 + Monthly Number)', fontsize = 12)
    
    #   Save figures

    figure_name = './DataMoviesACC/Timeseries_Accuracy_000' + str(index_movie) + '.png'
    plt.savefig(figure_name,dpi=150)
    
    plt.close()
    
    return 


    ######################################################################
    
def map_seismicity(NELat, NELng, SWLat, SWLng, \
        NELat_local, NELng_local, SWLat_local, SWLng_local, plot_start_year, Location, catalog, mag_large_plot, mag_large, min_mag):


    #   Note:  This uses the new Cartopy interface
    #
    #   -----------------------------------------
    #
    #   Define plot map
    
    dateline_crossing = False
    
    #   Define coordinates
    left_long   = SWLng_local
    right_long  = NELng_local
    top_lat     = SWLat_local
    bottom_lat  = NELat_local
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    longitude_labels = [left_long, right_long]
    longitude_labels_dateline = [left_long, 180, right_long, 360]   #   If the map crosses the dateline
    
    central_long_value = 0
    if dateline_crossing:
        central_long_value = 180
        
    ax = plt.axes(projection=ccrs.PlateCarree(central_longitude=central_long_value))
    ax.set_extent([left_long, right_long, bottom_lat, top_lat])

    # Create a feature for States/Admin 1 regions at 1:50m from Natural Earth
    states_provinces = cfeature.NaturalEarthFeature(
        category='cultural',
        name='admin_1_states_provinces_lines',
        scale='50m',
        facecolor='none')

    land_10m = cfeature.NaturalEarthFeature('physical', 'land', '10m',
                                        edgecolor='face',
                                        facecolor='coral')
                                        

                                        
    ocean_10m_3000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_H_3000', '10m',
#                                         edgecolor='black',
                                        facecolor='#0000FF',
                                        alpha = 0.3)
                                        

                                        
    lakes_10m = cfeature.NaturalEarthFeature('physical', 'lakes', '10m',
#                                        edgecolor='black',
                                        facecolor='blue',
                                        alpha = 0.75)
                                        
    rivers_and_lakes = cfeature.NaturalEarthFeature('physical', 'rivers_lakes_centerlines', '10m',
#                                        edgecolor='aqua',
                                        facecolor='blue',
                                        alpha = 0.75)

    ax.add_feature(ocean_10m_3000)

    ax.add_feature(cfeature.BORDERS, linestyle='-', alpha=.5, linewidth=0.5)
    ax.add_feature(cfeature.LAKES, alpha=0.95)
    ax.add_feature(cfeature.RIVERS, linewidth= 0.5)
    ax.add_feature(cfeature.STATES, edgecolor='gray',linewidth= 0.5)
#     ax.add_feature(states_provinces, edgecolor='gray')
    ax.coastlines(resolution='10m', color='black', linewidth=0.5)
    
#     stamen_terrain = cimgt.StamenTerrain()
    stamen_terrain = cimgt.Stamen('terrain-background')
    #   Zoom level should not be set to higher than about 6
    ax.add_image(stamen_terrain, 6)

    if dateline_crossing == False:
        gl = ax.gridlines(crs = ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.25, color='black', alpha=0.5, linestyle='dotted')
                   
    if dateline_crossing == True:
        gl = ax.gridlines(xlocs=longitude_labels_dateline, draw_labels=True,
                   linewidth=1.0, color='white', alpha=0.5, linestyle='--')

    gl.top_labels = False
    gl.right_labels = False
    gl.xlines = True
    gl.ylines = True

    if catalog == 'LosAngeles':
        gl.xlocator = mticker.FixedLocator([-112,-114,-116, -118, -120, -122])
    
    if catalog == 'Tokyo':
        gl.xlocator = mticker.FixedLocator([132,134,136, 138, 140, 142, 144, 146])

    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    
    #   -----------------------------------------
    #   Put california faults on the map
    
    input_file_name = './California_Faults.txt'
    input_file  =   open(input_file_name, 'r')
    
    for line in input_file:
        items = line.strip().split()
        number_points = int(len(items)/2)
        
        for i in range(number_points-1):
            x = [float(items[2*i]),float(items[2*i+2])]
            y = [float(items[2*i+1]), float(items[2*i+3])]
            ax.plot(x,y,'-', color='darkgreen',lw=0.55, zorder=2)
    
    input_file.close()
    #    
    #   -----------------------------------------
    #
    #   Plot the data
    
    mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = \
            SEISRFileMethods.read_regional_catalog(min_mag)
            
    for i in range(len(mag_array)): #   First plot them all as black dots
        if float(mag_array[i]) >= min_mag and float(year_array[i]) >= plot_start_year:
            ax.plot(float(lng_array[i]), float(lat_array[i]), '.k', ms=1, zorder=1)
        
        if float(mag_array[i]) >= 6.0 and float(mag_array[i]) < 6.89999  and float(year_array[i]) >= plot_start_year:
 #            ax.plot(float(lng_array[i]), float(lat_array[i]), 'g*', ms=11, zorder=2)
            ax.plot(float(lng_array[i]), float(lat_array[i]), 'o', mec='b', mfc='None', mew=1.25, \
                ms=6, zorder=2)
            
        if float(mag_array[i]) >= 6.89999 and float(year_array[i]) >= plot_start_year:
#             ax.plot(float(lng_array[i]), float(lat_array[i]), 'y*', ms=15, zorder=2)
            ax.plot(float(lng_array[i]), float(lat_array[i]), 'o', mec='r', mfc='None', mew=1.25,\
                ms=12, zorder=2)
# 
    SupTitle_text = 'Seismicity for $M\geq$' + str(min_mag)  + ' after ' + str(plot_start_year)
    plt.suptitle(SupTitle_text, fontsize=14, y=0.98)
#     
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location 
    plt.title(Title_text, fontsize=10)
    
    #   -------------------------------------------------------------

    figure_name = './Data/Seismicity_Map_' + Location + '_' + str(plot_start_year) + '.png'
    plt.savefig(figure_name,dpi=600)

    plt.show()
    
    plt.close()

    #   -------------------------------------------------------------
    
    return None

    ######################################################################
    
def plot_Reliability(observed_stats_list, precision_list, \
                    forecast_interval, mag_large, mag_large_plot, min_mag,\
                    data_string_title, number_thresholds, NELng_local, SWLng_local, NELat_local, SWLat_local, \
                    Location, NSteps, delta_time, lambda_mult):
                    
    fig, ax = plt.subplots()

    label_text = 'Reliability for $M\geq$'+ str(mag_large) 
    
    precision_list = [precision_list[i]*100.0 for i in range(len(precision_list))]
    observed_stats_list = [observed_stats_list[i]*100.0 for i in range(len(observed_stats_list))]

    ax.plot(precision_list, observed_stats_list, linestyle='-', lw=1.0, color='b', zorder=3, label=label_text)
    
    ax.minorticks_on()
        
    x_line = [0.,100.]
    y_line = [0.,100.]
    
    ax.plot(x_line, y_line, linestyle='-', lw=1.0, color='k', zorder=2, label = 'Random Mean')
    
    #   -----------------------------------------------------------------------
    
    SupTitle_text = 'Reliability'
    plt.suptitle(SupTitle_text, fontsize=12, y = 0.96)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
#     
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location 
    plt.title(Title_text, fontsize=10)
    
    plt.ylabel('Observed Frequency (%)', fontsize = 12)
    plt.xlabel('Probability (PPV, %)', fontsize = 12)
    
    figure_name = './Data/Reliability_' + Location + '.png'
    plt.savefig(figure_name,dpi=200)

    plt.show()
                    
    return
    
    ######################################################################
    
def map_RI_contours(NELat_local, NELng_local, SWLat_local, SWLng_local, \
        grid_size, start_year, end_year, time_stamp, catalog, min_mag, Location):

    
    #   Note:  This uses the new Cartopy interface
    #
    #   -----------------------------------------
    #   Set up data to plot
    
    mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = \
            ISRFileMethods.read_regional_catalog(min_mag)
            
    lat, lng, lat_index, lng_index = ISRFileMethods.read_grid_file()
    
    #
    #   -----------------------------------------
    #   Define plot map
    
    dateline_crossing = False
    
    #   California
    left_long   = SWLng_local
    right_long  = NELng_local - 0.1
    top_lat     = SWLat_local - 0.1
    bottom_lat  = NELat_local
    
    
    longitude_labels = [left_long, right_long]
    longitude_labels_dateline = [left_long, 180, right_long, 360]   #   If the map crosses the dateline
    
    central_long_value = 0
    if dateline_crossing:
        central_long_value = 180
        
    ax = plt.axes(projection=ccrs.PlateCarree(central_longitude=central_long_value))
    ax.set_extent([left_long, right_long, bottom_lat, top_lat])

    # Create a feature for States/Admin 1 regions at 1:50m from Natural Earth
    states_provinces = cfeature.NaturalEarthFeature(
        category='cultural',
        name='admin_1_states_provinces_lines',
        scale='50m',
        facecolor='none')

    land_10m = cfeature.NaturalEarthFeature('physical', 'land', '10m',
                                        edgecolor='face',
                                        facecolor='coral')
                                        

                                        
    ocean_10m_3000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_H_3000', '10m',
#                                         edgecolor='black',
                                        facecolor='#0000FF',
                                        alpha = 0.3)
                                        

                                        
    lakes_10m = cfeature.NaturalEarthFeature('physical', 'lakes', '10m',
#                                        edgecolor='black',
                                        facecolor='blue',
                                        alpha = 0.75)
                                        
    rivers_and_lakes = cfeature.NaturalEarthFeature('physical', 'rivers_lakes_centerlines', '10m',
#                                        edgecolor='aqua',
                                        facecolor='blue',
                                        alpha = 0.75)

    ax.add_feature(ocean_10m_3000)

    ax.add_feature(cfeature.BORDERS, linestyle='-', alpha=.5, linewidth=0.5)
    ax.add_feature(cfeature.LAKES, alpha=0.95)
    ax.add_feature(cfeature.RIVERS, linewidth= 0.5)
    ax.add_feature(cfeature.STATES, edgecolor='gray',linewidth= 0.5)
#     ax.add_feature(states_provinces, edgecolor='gray')
    ax.coastlines(resolution='10m', color='black', linewidth=0.5)
    
    stamen_terrain = cimgt.Stamen('terrain-background')
    
    #   Zoom level should not be set to higher than about 6
    ax.add_image(stamen_terrain, 6)

    if dateline_crossing == False:
        gl = ax.gridlines(crs = ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.25, color='black', alpha=0.5, linestyle='dotted')
                   
    if dateline_crossing == True:
        gl = ax.gridlines(xlocs=longitude_labels_dateline, draw_labels=True,
                   linewidth=1.0, color='white', alpha=0.5, linestyle='--')

    gl.top_labels = False
    gl.right_labels = False
    gl.xlines = True
    gl.ylines = True

    if catalog == 'LosAngeles':
        gl.xlocator = mticker.FixedLocator([-112,-114,-116, -118, -120, -122])
    
    if catalog == 'Tokyo':
        gl.xlocator = mticker.FixedLocator([132,134,136, 138, 140, 142, 144, 146])
#    gl.xlocator = mticker.FixedLocator([left_side, right_side])

#    gl.xlocator = mticker.FixedLocator([left_side, right_side])

    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    
    #   -----------------------------------------
    #   Put california faults on the map
    
    input_file_name = './California_Faults.txt'
    input_file  =   open(input_file_name, 'r')
    
    for line in input_file:
        items = line.strip().split()
        number_points = int(len(items)/2)
        
        for i in range(number_points-1):
            x = [float(items[2*i]),float(items[2*i+2])]
            y = [float(items[2*i+1]), float(items[2*i+3])]
            ax.plot(x,y,'r-', lw=0.55, zorder=2)
            
    input_file.close()
    #   -----------------------------------------
    #
    #   Read the timeseries data from timeseries.txt  Then use only the data between 
    #       start_date and end_date to contour
    
    time_bins, timeseries = ISRFileMethods.get_timeseries_data(min_mag)
    

    lat_grid,lng_grid,lat_indices,lng_indices     = ISRFileMethods.read_grid_file()
    
    nlat = int( (NELat_local - SWLat_local)/grid_size )
    nlng = int( (NELng_local - SWLng_local)/grid_size)
    
    half_grid_size = grid_size * 0.5
    
    lat_array   =   [SWLat_local + half_grid_size + i*grid_size for i in range(nlat)]
    lng_array   =   [SWLng_local + half_grid_size + i* grid_size for i in range(nlng)]
    
    ntotal = nlat*nlng

    relative_intensity =   np.zeros((nlat,nlng)) #   Define an empty array with nlat rows and nlon columns
    
    for i in range(len(lng_grid)):
        try:
            relative_intensity[lat_index[i]][lng_index[i]] =   math.log(1. + sum(timeseries[i]),10)
        except:
            pass
# 
    SupTitle_text = '$Log_{10}$(Relative Intensity) ' + ' From ' + str(start_year) + ' To ' + str(end_year)
    plt.suptitle(SupTitle_text, fontsize=11)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
#     
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location 
    plt.title(Title_text, fontsize=10)
    
    relative_intensity =  scipy.ndimage.zoom(relative_intensity, 15)
    lng_array    =  scipy.ndimage.zoom(lng_array, 15)
    lat_array    =  scipy.ndimage.zoom(lat_array, 15)   
    
    relative_intensity = np.ma.array(relative_intensity, mask = abs(relative_intensity) < 0.75)
    
    im = ax.contourf( lng_array, lat_array, relative_intensity, 10, cmap='rainbow', alpha = 0.50, transform=ccrs.PlateCarree())
    ax.contourf(lng_array, lat_array, relative_intensity, 10, transform=ccrs.PlateCarree(), cmap='rainbow', alpha = 0.50, zorder=3)
    
    plt.colorbar(im)
#     

    #   -------------------------------------------------------------

    #   Save the figures

    figure_name = './Data/Relative_Intensity_' + '_' + str(start_year) + '_' + str(end_year) + '.png'
    plt.savefig(figure_name,dpi=600)
    
    plt.close()

    #   -------------------------------------------------------------
    
    return None

    ######################################################################
    
 
def map_RTI_time_slice_contours(NELat_local, NELng_local, SWLat_local, SWLng_local, \
            grid_size, min_mag, lower_mag, Location, index_movie, delta_time_interval, catalog,\
            timeseries_EMA_reduced, time_list_reduced, date_bins_reduced, NSteps, forecast_interval,lambda_mult, min_rate,\
            mag_array_large, date_array_large, time_array_large, year_array_large, \
            depth_array_large, lat_array_large, lng_array_large):
            

    
    #   Note:  This uses the new Cartopy interface
    #
    #   -----------------------------------------
    #   Set up data to plot
    
    lat, lng, lat_index, lng_index = SEISRFileMethods.read_grid_file()
    
    #
    #   -----------------------------------------
    #   Define plot map
    
    dateline_crossing = False
    
    #   California
    left_long   = SWLng_local
    right_long  = NELng_local - 0.1
    top_lat     = SWLat_local - 0.1
    bottom_lat  = NELat_local
    
    
    longitude_labels = [left_long, right_long]
    longitude_labels_dateline = [left_long, 180, right_long, 360]   #   If the map crosses the dateline
    
    central_long_value = 0
    if dateline_crossing:
        central_long_value = 180
        
    ax = plt.axes(projection=ccrs.PlateCarree(central_longitude=central_long_value))
    ax.set_extent([left_long, right_long, bottom_lat, top_lat])

    # Create a feature for States/Admin 1 regions at 1:50m from Natural Earth
    states_provinces = cfeature.NaturalEarthFeature(
        category='cultural',
        name='admin_1_states_provinces_lines',
        scale='50m',
        facecolor='none')

    land_10m = cfeature.NaturalEarthFeature('physical', 'land', '10m',
                                        edgecolor='face',
                                        facecolor='coral')
                                        

                                        
    ocean_10m_3000 = cfeature.NaturalEarthFeature('physical', 'bathymetry_H_3000', '10m',
#                                         edgecolor='black',
                                        facecolor='#0000FF',
                                        alpha = 0.3)
                                        

                                        
    lakes_10m = cfeature.NaturalEarthFeature('physical', 'lakes', '10m',
#                                        edgecolor='black',
                                        facecolor='blue',
                                        alpha = 0.75)
                                        
    rivers_and_lakes = cfeature.NaturalEarthFeature('physical', 'rivers_lakes_centerlines', '10m',
#                                        edgecolor='aqua',
                                        facecolor='blue',
                                        alpha = 0.75)

#     ax.add_feature(ocean_10m_3000)

    ax.add_feature(cfeature.BORDERS, linestyle='-', alpha=.5, linewidth=0.5)
    ax.add_feature(cfeature.LAKES, alpha=0.95)
    ax.add_feature(cfeature.RIVERS, linewidth= 0.5)
    ax.add_feature(cfeature.STATES, edgecolor='gray',linewidth= 0.5)
#     ax.add_feature(states_provinces, edgecolor='gray')
    ax.coastlines(resolution='10m', color='black', linewidth=0.5)
    
    stamen_terrain = cimgt.Stamen('terrain-background')
    
    #   Zoom level should not be set to higher than about 6

    if dateline_crossing == False:
        gl = ax.gridlines(crs = ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.25, color='black', alpha=0.5, linestyle='dotted')
                   
    if dateline_crossing == True:
        gl = ax.gridlines(xlocs=longitude_labels_dateline, draw_labels=True,
                   linewidth=1.0, color='white', alpha=0.5, linestyle='--')

    gl.top_labels = False
    gl.right_labels = False
    gl.xlines = True
    gl.ylines = True

    if catalog == 'LosAngeles':
        gl.xlocator = mticker.FixedLocator([-112,-114,-116, -118, -120, -122])
    
    if catalog == 'Tokyo':
        gl.xlocator = mticker.FixedLocator([132,134,136, 138, 140, 142, 144, 146])

    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    
    #   -----------------------------------------
    #   Put california faults on the map
    
    input_file_name = './California_Faults.txt'
    input_file  =   open(input_file_name, 'r')
    
    for line in input_file:
        items = line.strip().split()
        number_points = int(len(items)/2)
        
        for i in range(number_points-1):
            x = [float(items[2*i]),float(items[2*i+2])]
            y = [float(items[2*i+1]), float(items[2*i+3])]
#             ax.plot(x,y,'r-', lw=0.55, zorder=2)
            ax.plot(x,y,'-', color='darkgreen',lw=0.55, zorder=2)
            
    input_file.close()
    
    #
    #   -----------------------------------------
    #

    levels_list = arange(0.1,1.1,0.1)
    
#   Define the Logistic Function: Short term EMA divided by Long term EMA

    ROC_event_list = \
            SEISRCalcMethods.classify_large_earthquakes_grid_boxes(NELat_local, NELng_local, SWLat_local, SWLng_local, \
                        grid_size, index_movie, time_list_reduced, forecast_interval,\
                        mag_array_large, year_array_large, depth_array_large, lat_array_large, lng_array_large) 
                        
    
    ROC_gridbox_threshold_list = \
                SEISRCalcMethods.sort_list_EQ_RTI_order(ROC_event_list,  NELat_local, NELng_local, SWLat_local, SWLng_local,\
                min_mag, index_movie, timeseries_EMA_reduced, NSteps, lambda_mult)
                
    #   -----------------------------------------
            
    lat_grid,lng_grid,lat_indices,lng_indices     = SEISRFileMethods.read_grid_file()
    
    nlat = int( (NELat_local - SWLat_local)/grid_size )
    nlng = int( (NELng_local - SWLng_local)/grid_size)
    
    half_grid_size = grid_size * 0.5
    
    lat_array   =   [SWLat_local + half_grid_size + i*grid_size for i in range(nlat)]
    lng_array   =   [SWLng_local + half_grid_size + i* grid_size for i in range(nlng)]
    
    ntotal = nlat*nlng

    relative_intensity =   np.zeros((nlat,nlng)) #   Define an empty array with nlat rows and nlon columns
    
    for i in range(len(lng_grid)):
        try:
            relative_intensity[lat_index[i]][lng_index[i]] =   ROC_gridbox_threshold_list[i]
        except:
            pass
# 
    SupTitle_text = '$Log_{10}$(1.0 + Relative Total Intensity in %)'
    plt.suptitle(SupTitle_text, fontsize=11)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
#     
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location\
            + ' on ' + str(date_bins_reduced[index_movie])
    plt.title(Title_text, fontsize=9)
    
    relative_intensity =  scipy.ndimage.zoom(relative_intensity, 15)
    lng_array    =  scipy.ndimage.zoom(lng_array, 15)  
    lat_array    =  scipy.ndimage.zoom(lat_array, 15)   
    
    #   -----------------------------------------
    #
    #   NOTE:   To find the correct levels, first just use levels=10 or similar.  See what that gives you, then define the
    #           levels_list
    
    #   Set the plot levels.  At the moment, levels are unscaled, so large values saturate
    
    levels_list = arange(0.1,1.1, 0.1)
    
    #   -----------------------------------------
    #
    #   Make the contour plots
    
    relative_intensity = np.ma.array(relative_intensity, mask = relative_intensity < levels_list[0])
    
    im = ax.contourf( lng_array, lat_array, relative_intensity, levels = levels_list, extend = "both", cmap='rainbow', alpha = 0.25,\
             transform=ccrs.PlateCarree())
    
    ax.contourf(lng_array, lat_array, relative_intensity, levels = levels_list, transform=ccrs.PlateCarree(), extend = "both",\
            cmap='rainbow', alpha = 0.25, zorder=3)
            
    plt.colorbar(im)
    #
    #   -----------------------------------------
    #
    #   Plot large earthquakes that occur within 3 years

    mag_array, date_array, time_array, year_array, depth_array, lat_array, lng_array = \
            SEISRFileMethods.read_regional_catalog(min_mag)
            
    lower_time = time_list_reduced[index_movie] 
    upper_time = lower_time + forecast_interval 
    
    for i in range(len(mag_array)): #   First plot them all as black dots

        
        if float(mag_array[i]) >= lower_mag and float(mag_array[i]) < 4.9 \
                and float(year_array[i]) >= lower_time and float(year_array[i]) < upper_time:
                
            ax.plot(float(lng_array[i]), float(lat_array[i]), 'o', mec='k', mfc='None', mew=0.5, ms = 2, zorder=4)
        
        if float(mag_array[i]) >= 5.0 and float(mag_array[i]) < 5.9 \
                and float(year_array[i]) >= lower_time and float(year_array[i]) < upper_time:
                
            ax.plot(float(lng_array[i]), float(lat_array[i]), 'o', mec='k', mfc='None', mew=0.75, ms=5, zorder=5)
        
        if float(mag_array[i]) >= 6.0 and float(mag_array[i]) < 6.89999  \
                and float(year_array[i]) >= lower_time and float(year_array[i]) < upper_time:
 
            ax.plot(float(lng_array[i]), float(lat_array[i]), 'o', mec='b', mfc='None', mew=0.75, \
                    ms=9, zorder=6)
            
        if float(mag_array[i]) >= 6.89999 and float(year_array[i]) >= lower_time and float(year_array[i]) < upper_time:

            ax.plot(float(lng_array[i]), float(lat_array[i]), 'o', mec='r', mfc='None', mew=0.75,\
                    ms=14, zorder=7)
                    
                    
    ax.plot(float(lng_array[i])+ 1000., float(lat_array[i])+1000., 'o', mec='k', mfc='None', mew=0.5, ms = 2, \
                    zorder=4, label= str(4.9) + '$ > M \geq $'+str(lower_mag))
                    
    ax.plot(float(lng_array[i])+ 1000., float(lat_array[i])+1000., 'o', mec='k', mfc='None', mew=0.75, ms=5, \
                    zorder=4, label='$5.9 > M \geq $'+str(5.0))
                    
    ax.plot(float(lng_array[i])+1000., float(lat_array[i])+1000., 'o', mec='b', mfc='None', mew=0.75, \
                    ms=9, zorder=4, label='\n$6.9 > M \geq 6.0$')
                    
    ax.plot(float(lng_array[i])+1000., float(lat_array[i])+1000., 'o', mec='r', mfc='None', mew=0.75,\
                    ms=14, zorder=4, label='\n$M \geq 6.9$')
                    
    #
    #   -----------------------------------------
    #
    
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'
        
    textstr =   '$T_{D}$ (Months): ' + str(NSteps) +\
                '\nTime Step: ' + str_time_interval +\
                '\nGrid Size: ' + str(grid_size) + '$^o$' +\
                '\n$R_{min}$: ' + str(round(min_rate,0)) +\
                '\n$M_{min}$: ' + str(round(min_mag,2))
    
    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    #     # place a text box in upper left in axes coords
    ax.text(0.98, 0.98, textstr, transform=ax.transAxes, fontsize=6,
        verticalalignment='top', horizontalalignment = 'right', bbox=props, linespacing = 1.8)
    
    title_text = 'Future Earthquakes\nWithin $T_W$ = ' + str(forecast_interval) + ' Years'
    leg = ax.legend(loc = 'lower left', title=title_text, fontsize=6)
    leg.set_title(title_text,prop={'size':6})   #   Set the title text font size

    #   Save the figures

    figure_name = './DataMoviesLogRTI/LogRTI_Time_Slice_000' +  str(index_movie) + '.png'
    plt.savefig(figure_name,dpi=300)
    
    
    plt.close()

    #   -------------------------------------------------------------
    
    return None

    ######################################################################
    
def plot_EMA_N_vs_lambda(EMA_N_list, lambda_min_list, skill_list, \
                plot_start_year, mag_large_plot, forecast_interval, \
                NELng_local, SWLng_local, NELat_local, SWLat_local, Location, start_year, end_year):
                
    fig, ax = plt.subplots()

    EMAN_array    =  scipy.ndimage.zoom(EMA_N_list, 15)
    lambda_array    =  scipy.ndimage.zoom(lambda_min_list, 15)   
    
    skill_tradeoff =   np.zeros((len(lambda_min_list),len(EMA_N_list))) #   Define an empty array with nlat rows and nlon columns
    
    print(len(EMA_N_list), len(lambda_min_list), skill_tradeoff.shape)
    
    k = 0
    for i in range(len(lambda_min_list)):
        for j in range(len(EMA_N_list)):
            skill_tradeoff[i][j] =  skill_list[k]
            k += 1
            
    skill_tradeoff =  scipy.ndimage.zoom(skill_tradeoff, 15)
                
    im = ax.contourf(EMAN_array, lambda_array, skill_tradeoff, 10, cmap='rainbow', alpha = 0.50)
    ax.contourf(EMAN_array, lambda_array, skill_tradeoff, 10, cmap='rainbow', alpha = 0.50, zorder=3)
    
    plt.colorbar(im)
    
    SupTitle_text = 'Skill Tradeoff: N vs. Lambda From ' + str(start_year) + ' To ' + str(end_year)
    plt.suptitle(SupTitle_text, fontsize=11)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
#     
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location 
    plt.title(Title_text, fontsize=10)
    
    plt.xlabel('N for EMA', fontsize = 12)
    plt.ylabel('$\lambda$ for Mean Number of Earthquakes', fontsize = 12)
    
#     plt.show()
    
    figure_name = './Data/Skill_Tradeoff_' + str(start_year) + '_' + str(end_year) + '.png'
    plt.savefig(figure_name,dpi=300)
    
    plt.close()
                
    return
    
    ######################################################################
    

def plot_spatial_ROC_diagram(tpr_list, fpr_list,  NSTau, delta_time_interval,\
        lower_mag, min_rate, min_mag, grid_size, begin_date_of_plot, end_date_of_plot, forecast_interval,\
        delta_deg_lat, delta_deg_lng, Location, info_tp, info_random, js_divergence, kl_divergence):

    fig, ax = plt.subplots()
    
    x = list(range(len(tpr_list[0])))
    x = [float(x[i])/float(len(tpr_list[0])) for i in range(len(tpr_list[0]))]
    x.append(1.)
    y=x
    
    skill_score_list = []
    
    tpr_mean_list = [0. for i in range(len(tpr_list[0]))]
    fpr_mean_list = [0. for i in range(len(fpr_list[0]))]
    
    for k in range(len(tpr_list)):
    
        true_positive_rate  = tpr_list[k]
        false_positive_rate = fpr_list[k]
    
        tpr_array = np.array(true_positive_rate)
        fpr_array = np.array(false_positive_rate)
    
        area_trapz = trapz(tpr_array, fpr_array)    #   Works with non-equidistantly tabulated data
#         print("Trap Area = ", area_trapz)
# 
        skill_score = round(area_trapz,3)
        skill_score_list.append(skill_score)
        
        ax.plot(false_positive_rate, true_positive_rate, '-', color='cyan', alpha = 0.5, lw = 1.15, zorder=2)
        
        for j in range(len(tpr_list[0])):
            tpr_mean_list[j] += true_positive_rate[j]
            fpr_mean_list[j] += false_positive_rate[j]
            
    tpr_mean = []
    fpr_mean = []
    number_ROC_curves = len(tpr_list)
    
    for j in range(len(tpr_mean_list)):
        tpr_mean.append(tpr_mean_list[j]/float(number_ROC_curves))
        fpr_mean.append(fpr_mean_list[j]/float(number_ROC_curves))
        
    ax.plot(fpr_mean, tpr_mean, '-', color='r', alpha = 1.0, lw = 1.15, zorder=2)
        
    skill_score_mean = np.mean(skill_score_list)
    skill_score_mean = round(skill_score_mean,3)
    
    relative_skill = abs(skill_score_mean - 0.5)
    
    skill_index = - 100.0 * (relative_skill * math.log2(relative_skill) + (1.-relative_skill) * math.log2(1.0-relative_skill)  )
    
    skill_score_std   = np.std(skill_score_list)
    skill_score_std   = round(skill_score_std,3)
    
    
    ax.plot(x,y,'--', color='k', zorder=1)
        
    ax.grid(True, lw = 0.5, which='major', linestyle='dotted')
    
#     ax.legend(loc = 'lower right', fontsize=8)
        
    SupTitle_text = 'Spatial Receiver Operating Characteristic'
    plt.suptitle(SupTitle_text, fontsize=11)
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location\
            + ' From ' + str(begin_date_of_plot) + ' to ' + str(end_date_of_plot)
    plt.title(Title_text, fontsize=9)
        
    plt.ylabel('True Positive Rate', fontsize = 10)
    plt.xlabel('False Positive Rate', fontsize = 10)
    
    #
    #   -----------------------------------------
    #

    test_time_interval = delta_time_interval/0.07692
    
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif(abs(test_time_interval-0.25) < 0.01):
        str_time_interval = '1 Week'
    elif(abs(test_time_interval-2.0) < 0.01):
        str_time_interval = '2 Months'
    elif(abs(test_time_interval-3.0) < 0.01):
        str_time_interval = '3 Months'
        
    textstr =   'Nowcast: ' + str(forecast_interval) + ' Years' +\
                '\nSkill: ' + str(round(skill_score_mean,2)) + '$\pm$' + str(round(skill_score_std,2)) +\
                '\nSkill Index = ' + str(round(skill_index,2)) + '%'\
                '\n$I_{ROC}$ = ' + str(round(info_tp,2)) + ' Bits' +\
                '\n$I_{Random}$ = ' + str(round(info_random, 2)) + ' Bits' +\
                '\n$JSDiv$ = ' + str(round(js_divergence, 2)) + ' Bits' +\
                '\n$KLDiv$ = ' + str(round(kl_divergence, 2)) + ' Bits' +\
                '\n$T_{D}$ (Months): ' + str(NSTau) +\
                '\nTime Step: ' + str_time_interval +\
                '\nGrid Size: ' + str(round(grid_size,3)) + '$^o$' +\
                '\n$R_{min}$: ' + str(round(min_rate,0)) +\
                '\n$M_{min}$: ' + str(round(min_mag,2))

    
    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)

    #     # place a text box in upper left in axes coords
    ax.text(0.98, 0.02, textstr, transform=ax.transAxes, fontsize=8,
        verticalalignment='bottom', horizontalalignment = 'right', bbox=props, linespacing = 1.8)

    plot_year = begin_date_of_plot[:4]
    figure_name = './Predictions/Spatial_ROC_Mmin' + str(min_mag) + '_Tau' + str(NSTau)  + '_Grid' + str(grid_size) \
            + '_' + plot_year + '.png'
    plt.savefig(figure_name,dpi=300)
    
    plt.close()
        
#     plt.show()

    return
    
        ######################################################################
    
def plot_mean_eqs_timeseries(timeseries, time_bins, date_bins, plot_start_year, mag_large_plot, forecast_interval, \
        NELng_local, SWLng_local, NELat_local, SWLat_local, Location, NSteps, delta_time_interval, min_mag, lambda_mult, min_rate):
#     
#
#   ------------------------------------------------------------
#
    year_large_eq, mag_large_eq, index_large_eq = SEISRCalcMethods.get_large_earthquakes(mag_large_plot,min_mag)
    
#
#   ------------------------------------------------------------
#

    eqs_list = []
    
    for i in range(len(time_bins)):        #   Over all bins
        eq_sum = 0
        
        for j in range(len(timeseries)):
            eq_sum += timeseries[j][i]
            
        eqs_list.append(eq_sum)
    
    eq_means = []
    time_list= []
    for i in range(1,len(eqs_list)):
        try:
            eq_means.append(np.mean(eqs_list[:i]))
            time_list.append(time_bins[i])
        except:
            pass
            
    fig, ax = plt.subplots()
    
    ax.plot(time_list, eq_means, linestyle='-', lw=1.0, color='b', zorder=3, label='Mean $M$ > ' + str(min_mag))

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    

   #   -------------------------------------------------------------
   
    year_large_eq, mag_large_eq, index_large_eq = \
            SEISRCalcMethods.adjust_year_times(year_large_eq, mag_large_eq, index_large_eq, time_bins, time_bins[0])

    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.0 and float(mag_large_eq[i]) < 6.89999:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymin,eq_means[index_large_eq[i] ]]
            
            ax.plot(x_eq, y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2)
            
    ax.plot(x_eq,y_eq, linestyle='dotted', color='k', lw=0.7, zorder=2, label = '6.9 $>$ M $\geq$ 6.0')
            
    for i in range(len(year_large_eq)):

        if float(mag_large_eq[i]) >= 6.89999:
            x_eq = [year_large_eq[i], year_large_eq[i]]
            y_eq = [ymin,eq_means[index_large_eq[i] ]]
            
            ax.plot(x_eq, y_eq, linestyle='--', color='r', lw=0.7, zorder=2)
            
    ax.plot(x_eq,y_eq, linestyle='--', color='r', lw=0.7, zorder=2, label='M $\geq$ 6.9')

    #   -------------------------------------------------------------
    
    min_plot_line = [ymin for i in range(len(time_list))]
    ax.fill_between(time_list, min_plot_line, eq_means, color='c', alpha=0.1, zorder=0)
    
#     plt.gca().invert_yaxis()
            
    ax.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    
    ax.legend(loc = 'lower right', fontsize=10)
    
    #     
    #   ------------------------------------------------------------
    #
            
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'
        
    textstr =   'Time Step: ' + str_time_interval +\
                '\n$M_{min}$: ' + str(round(min_mag,2))

# 
#   ------------------------------------------------------------
#

    ax.minorticks_on()
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    SupTitle_text = 'Mean Number of Small Earthquakes vs. Time'

    plt.suptitle(SupTitle_text, fontsize=14, y = 0.98)
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location
            
    plt.title(Title_text, fontsize=10)
    
    plt.ylabel('Mean Monthly Number', fontsize = 12)
    plt.xlabel('Time (Year)', fontsize = 12)
    
    #   Save figure
    
    data_string_title = 'Mean_Earthquake_Timeseries' 

    figure_name = './Data/SEISR_' + data_string_title + '_' + str(plot_start_year) + '.png'
    plt.savefig(figure_name,dpi=300)
#     
#     plt.show()
#     matplotlib.pyplot.close('all')
    plt.close('all')

    return 
    
    ######################################################################
    
def plot_temporal_skill_info_vs_TW(forecast_interval_list, temp_skill_score_list, info_random_list, info_tpr_list, info_fpr_list,\
        info_roc_list, Location, min_rate, max_rate, NSteps, delta_time_interval, min_mag, mag_large, delta_deg_lat, \
        delta_deg_lng, plot_start_year, number_thresholds):
        
    fig, (ax1, ax2, ax3) = plt.subplots(3,1)
    
    #   Skill Plot
    
    #   Find the approximate roots
    
    roots = []
    for i in range(1,len(temp_skill_score_list)):
        if np.sign(temp_skill_score_list[i]-0.5) != np.sign(temp_skill_score_list[i-1]-0.5) :
            roots.append(i)
            
    ax1.plot(forecast_interval_list, temp_skill_score_list, zorder = 5, lw=0.75,  \
        label='Skill >0.5: True Positive Skill\nSkill <0.5: True Negative Skill')
    
    zero_line = [0.5 for i in range(len(forecast_interval_list))]
    
    ax1.plot(forecast_interval_list, zero_line, lw = 0.5, color='k', linestyle='dashed')
    
    ymin1, ymax1 = plt.ylim()
    xmin1, xmax1 = plt.ylim()
    
    max_skill = max(temp_skill_score_list)
    max_skill_index = temp_skill_score_list.index(max_skill)
    
    xmax_skill = [forecast_interval_list[max_skill_index], forecast_interval_list[max_skill_index]]
    ymax_skill = [ymin1, ymax1]
    
    ax1.plot(xmax_skill, ymax_skill, lw = 0.75, color='b', linestyle='dashed')
    
    for i in range(len(roots)):
        xroot = [forecast_interval_list[roots[0]], forecast_interval_list[roots[0]]]
        yroot = [ymin1, ymax1]
        ax1.plot(xroot, yroot, lw = 0.75, color='r', linestyle='dashed')
        
    test_time_interval = delta_time_interval/0.07692
    
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif(abs(test_time_interval-0.25) < 0.01):
        str_time_interval = '1 Week'
    elif(abs(test_time_interval-2.0) < 0.01):
        str_time_interval = '2 Months'
    elif(abs(test_time_interval-3.0) < 0.01):
        str_time_interval = '3 Months'
        
    #   -------------------------------------------------------------
    #   Skill Index Plot
    
    skill_index_list = []
    
    for i in range(len(temp_skill_score_list)):
        relative_skill = abs(temp_skill_score_list[i] - 0.5)
        skill_index = - 100.0 * (relative_skill * math.log2(relative_skill) + (1.-relative_skill) * math.log2(1.0-relative_skill)  )
        skill_index_list.append(skill_index)
        
    for i in range(len(roots)):
        skill_index_list[roots[i]] = 0.
    
    ax2.plot(forecast_interval_list, skill_index_list, lw=0.75)
    
    ymin2, ymax2 = plt.ylim()
    
    xmax_skill = [forecast_interval_list[max_skill_index], forecast_interval_list[max_skill_index]]
    ymax_skill = [100.*ymin2, 100.*ymax2]   #   In percentage
    ax2.plot(xmax_skill, ymax_skill, lw = 0.75, color='b', linestyle='dashed', label = 'Maximum Skill @ $T_W$ = ' + \
            str(forecast_interval_list[max_skill_index]) + ' Years')
            
    for i in range(len(roots)):
        xroot = [forecast_interval_list[roots[i]], forecast_interval_list[roots[i]]]
        yroot = [100.*ymin2, 100.*ymax2]
        ax2.plot(xroot, yroot, lw = 0.75, color='r', linestyle='dashed', label = 'No Skill @ $T_W$ = ' + \
            str(forecast_interval_list[roots[i]]) + ' Years')
    
    #   -------------------------------------------------------------
    #   Information Entropy Plot
        
    ax3.plot(forecast_interval_list, info_random_list, color='k', lw = 0.75, linestyle='dashed', \
        label='Random ($N_{TH}$=' + str(number_thresholds) + ')')
#     ax3.plot(forecast_interval_list, info_tpr_list, lw=0.75, color = 'r', label='True Positive Rate')
#     ax3.plot(forecast_interval_list, info_fpr_list, lw=0.75, color = 'b', label='False_Positive_Rate')
    ax3.plot(forecast_interval_list, info_roc_list, lw=0.75, label='ROC Information Entropy')
    
    ymin3, ymax3 = plt.ylim()
    
    xmax_skill = [forecast_interval_list[max_skill_index], forecast_interval_list[max_skill_index]]
    ymax_skill = [ymin3, ymax3]
    ax3.plot(xmax_skill, ymax_skill, lw = 0.75, color='b', linestyle='dashed')
            
    for i in range(len(roots)):
        xroot = [forecast_interval_list[roots[i]], forecast_interval_list[roots[i]]]
        yroot = [ymin3, ymax3]
        ax3.plot(xroot, yroot, lw = 0.75, color='r', linestyle='dashed')
            
    #   -------------------------------------------------------------
    #   Data for Text Boxes
        
    test_time_interval = delta_time_interval/0.07692
    
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif(abs(test_time_interval-0.25) < 0.01):
        str_time_interval = '1 Week'
    elif(abs(test_time_interval-2.0) < 0.01):
        str_time_interval = '2 Months'
    elif(abs(test_time_interval-3.0) < 0.01):
        str_time_interval = '3 Months'
        
    Rmax_plot = str(round(max_rate,0))
    if max_rate > 10000:
        Rmax_plot = 'Inf.'
        
    textstr =   'Max. Skill: ' + str(round(max_skill,2)) +\
                '\nEMA Samples (N): ' + str(NSteps) +\
                '\nTime Step: ' + str_time_interval +\
                '\n$R_{min}$: ' + str(round(min_rate,0)) +\
                '\n$R_{max}$: ' + Rmax_plot +\
                '\nTarget Mag: ' + str(round(mag_large,2)) +\
                '\n$M_{min}$: ' + str(round(min_mag,2))

    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.85)
    
    ax3.text(0.99, 0.05, textstr, transform=ax3.transAxes, fontsize=4,
        verticalalignment='bottom', horizontalalignment = 'right', bbox=props, linespacing = 1.8)
        
    textstr =   'Skill >0.5: True Positive Skill' +\
                '\nSkill <0.5: True Negative Skill'

    #     # these are matplotlib.patch.Patch properties
    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)
    
    ax1.text(0.5, 0.05, textstr, transform=ax1.transAxes, fontsize=6,
        verticalalignment='bottom', horizontalalignment = 'center', bbox=props, linespacing = 1.8)
    
#     leg = ax1.legend(handlelength=0, handletextpad=0, fancybox=True, loc = 'lower center', fontsize=6, labelspacing=0.5)
#     for item in leg.legendHandles:
#         item.set_visible(False)
        
    ax2.legend(loc = 'lower center', fontsize=6)
    ax3.legend(loc = 'lower center', fontsize=6)

    SupTitle_text = 'Temporal ROC Skill & Information vs. Future Time Window ($T_W$)'
    plt.suptitle(SupTitle_text, fontsize=12, y = 0.98)
    
    Title_text = 'Within ' + str(delta_deg_lat) + '$^o$ Latitude and ' + str(delta_deg_lng) + '$^o$ Longitude of ' + Location
    ax1.set_title(Title_text, fontsize=10)
    
#     min_plot_line = [ymin1 for i in range(len(forecast_interval_list))]
    min_plot_line = [0.5 for i in range(len(forecast_interval_list))]
    ax1.fill_between(forecast_interval_list , min_plot_line, temp_skill_score_list, color='c', alpha=0.1, zorder=0)
    
    min_plot_line = [ymin2 for i in range(len(forecast_interval_list))]
    ax2.fill_between(forecast_interval_list , min_plot_line, skill_index_list, color='c', alpha=0.1, zorder=0)
    
    min_plot_line = [ymin3 for i in range(len(forecast_interval_list))]
    ax3.fill_between(forecast_interval_list , min_plot_line, info_roc_list, color='c', alpha=0.1, zorder=0)
#     ax3.fill_between(forecast_interval_list , info_fpr_list, info_tpr_list, color='greenyellow', alpha=0.1, zorder=0)
    
    ax1.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    ax2.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    ax3.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    
    ax1.minorticks_on()
    ax2.minorticks_on()
    ax3.minorticks_on()
    
    ax1.set_ylabel('ROC Skill', fontsize = 8)
    ax1.set_xlabel('', fontsize = 8)
        
    ax2.set_ylabel('ROC Skill Index (%)', fontsize = 8)
    ax2.set_xlabel('', fontsize = 8)
    
    ax3.set_ylabel('ROC Information\nEntropy (Bits)', fontsize = 8)
    ax3.set_xlabel('Time Window $T_W$(Year)', fontsize = 8)
    
    #   Save figure
    
    data_string_title = 'Temporal_ROC_Skill_vs_TW' 

    figure_name = './Predictions/' + data_string_title + '_' + str(plot_start_year) + '.png'
    plt.savefig(figure_name,dpi=300)
    plt.close('all')

        
    return
    
    ######################################################################

def plot_seismic_attractor(time_list_reduced, log_number_reduced, plot_start_year, mag_large_plot,\
        NELng_local, SWLng_local, NELat_local, SWLat_local, Location, NSteps, delta_time_interval, min_mag, lambda_mult, min_rate,\
        max_rate, forecast_interval):
        
#
#   ------------------------------------------------------------
#
        
    fig, ax = plt.subplots()
    
    state_variable_i            =   log_number_reduced[:-1]
    state_variable_iplus1       =   log_number_reduced[1:]
    
#     print(len(state_variable_i), state_variable_i)
#     print()    
#     print(len(state_variable_iplus1), state_variable_iplus1)
    
#     ax.plot(state_variable_i, state_variable_iplus1, linestyle='None', marker='.', markersize=3, zorder=3)
    ax.plot(state_variable_i, state_variable_iplus1, linestyle='-', lw= 0.35, marker='.', markersize=3, zorder=3)
    
    for i in range(1,len(state_variable_i)):
        thetan      = [log_number_reduced[i-1]]
        thetanp1    = [log_number_reduced[i]]
        ax.plot(thetan, thetanp1, linestyle='None', marker='.', markersize=8, zorder=3)
        
    min_theta = min(log_number_reduced)
    max_theta = max(log_number_reduced)
    
    ax.plot([min_theta, max_theta], [min_theta, max_theta], 'k--', lw=0.75, zorder=1)
    ax.plot([min_theta], [min_theta], marker='o', markersize=15, mfc='None', mec='k', mew=1.5, zorder=0)

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    
#     max_plot_line = [ymax for i in range(len(time_list_reduced))]
#     ax.fill_between(time_list_reduced , max_plot_line, log_number_reduced, color='c', alpha=0.1, zorder=0)
    
    plt.gca().invert_yaxis()
    plt.gca().invert_xaxis()
            
    ax.grid(True, lw = 0.5, which='major', linestyle='dotted', axis = 'both')
    
#     ax.legend(loc = 'upper left', fontsize=7)
    
    #     
    #   ------------------------------------------------------------
    #
            
    test_time_interval = delta_time_interval/0.07692
    if abs(test_time_interval-1.0) <0.01:
        str_time_interval = '1 Month'
    elif abs(test_time_interval-0.25) < 0.01:
        str_time_interval = '1 Week'
    elif abs(test_time_interval-2.0) < 0.01:
        str_time_interval = '2 Months'
    elif abs(test_time_interval-3.0) < 0.01:
        str_time_interval = '3 Months'
        
    Rmax_plot = str(round(max_rate,0))
    if max_rate > 10000:
        Rmax_plot = 'Inf.'
        
    textstr =   'EMA Samples (N): ' + str(NSteps) +\
                '\nTime Step: ' + str_time_interval +\
                '\n$R_{min}$: ' + str(round(min_rate,0)) +\
                '\n$R_{max}$: ' + Rmax_plot +\
                '\n$M_{min}$: ' + str(round(min_mag,2))

# 
#     # these are matplotlib.patch.Patch properties
 #    props = dict(boxstyle='round', facecolor='white', edgecolor = 'gray', alpha=0.75)
# 
# #     # place a text box in upper left in axes coords
#     ax.text(0.015, 0.02, textstr, transform=ax.transAxes, fontsize=7,
#         verticalalignment='bottom', horizontalalignment = 'left', bbox=props, linespacing = 1.8)


#   ------------------------------------------------------------
#

    ax.minorticks_on()
    
    ax.tick_params(axis='both', labelsize=9)
    
    delta_deg_lat = (NELat_local  - SWLat_local) * 0.5
    delta_deg_lng = (NELng_local  - SWLng_local) * 0.5
    
    SupTitle_text = 'Attractor for Seismic State $\Theta(t)$ ' 

    plt.suptitle(SupTitle_text, fontsize=12, y = 0.96)
    
    Title_text = 'Within ' + str(round(delta_deg_lat,2)) + '$^o$ Latitude and ' + str(round(delta_deg_lng,2)) + '$^o$ Longitude of ' + Location\
        + ' (Note Inverted Axes)'
            
    plt.title(Title_text, fontsize=9)
    
    plt.ylabel('$\Theta(t_{n+1})$', fontsize = 9)
    plt.xlabel('$\Theta(t_{n})$', fontsize = 9)
    
    data_string_title = 'Attractor' + '_FI' + str(forecast_interval) + '_TTI' + str(test_time_interval) + \
            '_NSTP' + str(NSteps) + '_MM' + str(min_mag) + '_CF' + str(lambda_mult) 

    figure_name = './Data/SEISR_' + data_string_title + '_' + str(plot_start_year) + '.png'
    plt.savefig(figure_name,dpi=600)
    
#     plt.show()
#     matplotlib.pyplot.close('all')
    plt.close('all')

    return 
    
    ######################################################################